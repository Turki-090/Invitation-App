import * as React from 'react';
/** WhatsApp number — LTR, Western digits, +966 prefix. */
export interface PhoneInputProps {
  countryCode?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  invalid?: boolean;
  disabled?: boolean;
  size?: 'sm'|'md'|'lg';
  style?: React.CSSProperties;
}
export function PhoneInput(props: PhoneInputProps): JSX.Element;
