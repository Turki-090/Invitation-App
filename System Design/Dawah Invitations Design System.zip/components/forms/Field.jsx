import React from 'react';
/** Label + control + hint/error wrapper. Errors are text (icon-free) in danger colour. */
export function Field({ label, hint, error, required = false, optionalLabel, htmlFor, children, style }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label ? <label htmlFor={htmlFor} style={{ fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--text-body)', display: 'flex', gap: 6, alignItems: 'baseline' }}>
        <span>{label}</span>
        {required ? <span aria-hidden style={{ color: 'var(--danger)' }}>*</span> : optionalLabel ? <span style={{ fontWeight: 400, color: 'var(--text-muted)' }}>{optionalLabel}</span> : null}
      </label> : null}
      {children}
      {error ? <p role="alert" style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--danger-fg)' }}>{error}</p> : hint ? <p style={{ margin: 0, fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{hint}</p> : null}
    </div>
  );
}
