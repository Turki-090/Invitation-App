Big tappable option card for invitation-type selection (host) and companion choice (guest).

```jsx
<ChoiceCard icon="users" title="عائلة / مجموعة بأسماء" description="رقم واحد، ويختار الضيف من يحضر" selected onClick={…} />
```

- Selection = 2px ink border + check disc; never colour alone.
- Stack vertically; full width.
