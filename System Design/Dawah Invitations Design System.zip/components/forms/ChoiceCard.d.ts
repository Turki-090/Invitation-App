import * as React from 'react';
/** Large selectable option card (invitation type; Me / Me+1 / Me+2). */
export interface ChoiceCardProps {
  selected?: boolean;
  title: React.ReactNode;
  description?: React.ReactNode;
  icon?: string;
  meta?: React.ReactNode;
  onClick?: () => void;
  size?: 'md'|'guest';
  disabled?: boolean;
  style?: React.CSSProperties;
}
export function ChoiceCard(props: ChoiceCardProps): JSX.Element;
