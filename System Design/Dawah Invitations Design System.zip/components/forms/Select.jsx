import React, { useState } from 'react';
import { Icon } from '../core/Icon.jsx';
import { inputFrame } from './Input.jsx';
/** Native select styled as an input. options: [{value,label}] */
export function Select({ options = [], value, onChange, placeholder, size = 'md', invalid = false, disabled = false, style }) {
  const [focus, setFocus] = useState(false);
  const H = { sm: 'var(--control-h-sm)', md: 'var(--control-h-md)', lg: 'var(--control-h-lg)' };
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center', height: H[size] || H.md, ...inputFrame(focus, invalid, disabled), ...style }}>
      <select value={value ?? ''} disabled={disabled} onChange={e => onChange && onChange(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ appearance: 'none', WebkitAppearance: 'none', width: '100%', height: '100%', border: 0, outline: 'none', background: 'transparent', padding: '0 36px 0 12px', paddingInlineStart: 12, paddingInlineEnd: 36, fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-md)', color: value ? 'var(--text-body)' : 'var(--text-muted)', boxShadow: 'none', cursor: disabled ? 'not-allowed' : 'pointer' }}>
        {placeholder ? <option value="" disabled>{placeholder}</option> : null}
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <span style={{ position: 'absolute', insetInlineEnd: 10, pointerEvents: 'none', display: 'inline-flex', color: 'var(--text-muted)' }}><Icon name="chevron-down" size={16} /></span>
    </div>
  );
}
