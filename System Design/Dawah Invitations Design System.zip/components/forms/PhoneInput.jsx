import React from 'react';
import { Input } from './Input.jsx';
/** WhatsApp number input — always LTR, Western digits, mono. Country code is a prefix (default +966). Pass invalid for "not a valid Saudi/GCC number" states. */
export function PhoneInput({ countryCode = '+966', value, onChange, placeholder = '5X XXX XXXX', invalid = false, disabled = false, size = 'md', style }) {
  return <Input dir="ltr" mono size={size} prefix={countryCode} icon="phone" inputMode="tel" autoComplete="tel-national" value={value} onChange={onChange} placeholder={placeholder} invalid={invalid} disabled={disabled} style={style} />;
}
