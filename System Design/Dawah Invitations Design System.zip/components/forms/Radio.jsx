import React from 'react';
/** Radio with label. Group by name. */
export function Radio({ checked = false, onChange, name, value, label, description, disabled = false, style }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: description ? 'flex-start' : 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }}>
      <span style={{ position: 'relative', display: 'inline-flex', flex: 'none', marginTop: description ? 2 : 0 }}>
        <input type="radio" name={name} value={value} checked={checked} disabled={disabled} onChange={() => onChange && onChange(value)} style={{ position: 'absolute', inset: 0, opacity: 0, margin: 0, width: '100%', height: '100%', cursor: 'inherit' }} />
        <span aria-hidden style={{ width: 20, height: 20, borderRadius: '50%', border: `${checked ? 6 : 1.5}px solid ${checked ? 'var(--ink)' : 'var(--border-strong)'}`, background: 'var(--surface-card)', transition: 'var(--transition-control)' }} />
      </span>
      {label ? <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontSize: 'var(--text-md)', lineHeight: 1.4 }}>{label}</span>
        {description ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{description}</span> : null}
      </span> : null}
    </label>
  );
}
