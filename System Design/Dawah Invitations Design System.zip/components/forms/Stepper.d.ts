import * as React from 'react';
/** Numeric stepper for companion counts. */
export interface StepperProps {
  value?: number;
  min?: number;
  max?: number;
  onChange?: (value: number) => void;
  size?: 'md'|'guest';
  format?: (n: number) => string;
  decLabel?: string;
  incLabel?: string;
  style?: React.CSSProperties;
}
export function Stepper(props: StepperProps): JSX.Element;
