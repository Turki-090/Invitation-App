Wraps a control with label, hint and error text.

```jsx
<Field label="رقم واتساب" required error="هذا الرقم موجود مسبقًا في هذه المناسبة"><PhoneInput invalid /></Field>
```

- Errors are sentences that say what to do; shown in place of the hint.
