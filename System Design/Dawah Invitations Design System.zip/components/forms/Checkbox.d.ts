import * as React from 'react';
/** Checkbox; size guest = 28px for member selection. */
export interface CheckboxProps {
  checked?: boolean;
  indeterminate?: boolean;
  onChange?: (checked: boolean) => void;
  label?: React.ReactNode;
  description?: React.ReactNode;
  disabled?: boolean;
  size?: 'md'|'guest';
  style?: React.CSSProperties;
}
export function Checkbox(props: CheckboxProps): JSX.Element;
