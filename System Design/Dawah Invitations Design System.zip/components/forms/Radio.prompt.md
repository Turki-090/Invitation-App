Radio for mutually exclusive settings (reminder rule, audience).

```jsx
<Radio name="aud" value="unsent" checked label="كل الدعوات غير المرسلة" description="٢٩ مجموعة" />
```

- For big visual choices (invitation type, companion count) use ChoiceCard instead.
