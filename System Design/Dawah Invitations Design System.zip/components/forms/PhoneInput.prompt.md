Phone number input that stays LTR with Western digits inside Arabic forms.

```jsx
<PhoneInput value={phone} onChange={e => setPhone(e.target.value)} />
```

- Pair with Field error for duplicate / invalid Saudi-GCC number states.
