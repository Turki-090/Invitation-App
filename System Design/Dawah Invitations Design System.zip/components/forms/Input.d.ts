import * as React from 'react';
/** Text input with optional icon/prefix/suffix.
 * @startingPoint section="Forms" subtitle="Inputs, phone, select, checks, switch, stepper" viewport="700x420" */
export interface InputProps {
  size?: 'sm'|'md'|'lg'|'guest';
  icon?: string;
  invalid?: boolean;
  disabled?: boolean;
  dir?: 'ltr'|'rtl';
  mono?: boolean;
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  type?: string;
  style?: React.CSSProperties;
  inputStyle?: React.CSSProperties;
}
export function Input(props: InputProps): JSX.Element;
