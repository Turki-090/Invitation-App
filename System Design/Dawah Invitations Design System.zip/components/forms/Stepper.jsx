import React from 'react';
import { Icon } from '../core/Icon.jsx';
/** Numeric stepper for companion counts (0–N). Buttons are 40px hit targets; `size="guest"` = 56px. */
export function Stepper({ value = 0, min = 0, max = 10, onChange, size = 'md', format, decLabel = 'أقل', incLabel = 'أكثر', style }) {
  const guest = size === 'guest';
  const h = guest ? 56 : 40;
  const btn = (dis) => ({ width: h, height: h, border: 0, background: 'transparent', color: dis ? 'var(--text-disabled)' : 'var(--text-body)', cursor: dis ? 'not-allowed' : 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: 'none' });
  const set = v => onChange && onChange(Math.min(max, Math.max(min, v)));
  return (
    <div role="group" style={{ display: 'inline-flex', alignItems: 'center', height: h, border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-control)', background: 'var(--surface-card)', overflow: 'hidden', ...style }}>
      <button type="button" aria-label={decLabel} disabled={value <= min} onClick={() => set(value - 1)} style={btn(value <= min)}><Icon name="minus" size={guest ? 22 : 18} /></button>
      <span className="num" aria-live="polite" style={{ minWidth: guest ? 64 : 44, textAlign: 'center', fontSize: guest ? 'var(--text-guest-xl)' : 'var(--text-lg)', fontWeight: 600, borderInline: '1px solid var(--border-default)', height: '100%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{format ? format(value) : value}</span>
      <button type="button" aria-label={incLabel} disabled={value >= max} onClick={() => set(value + 1)} style={btn(value >= max)}><Icon name="plus" size={guest ? 22 : 18} /></button>
    </div>
  );
}
