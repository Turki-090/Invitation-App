import React, { useState } from 'react';
import { Icon } from '../core/Icon.jsx';
/** Large selectable option card — invitation type picker (host) and "Me only / Me + 1 / Me + 2" (guest). Selection is shown by border + check icon, never colour alone. */
export function ChoiceCard({ selected = false, title, description, icon, meta, onClick, size = 'md', disabled = false, style }) {
  const [hov, setHov] = useState(false);
  const guest = size === 'guest';
  return (
    <button type="button" role="radio" aria-checked={selected} disabled={disabled} onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: 'flex', alignItems: 'center', gap: 14, width: '100%', textAlign: 'start', padding: guest ? '16px 18px' : '14px 16px', minHeight: guest ? 64 : 56, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, fontFamily: 'inherit',
        background: selected ? (guest ? 'rgba(154,118,66,.10)' : 'var(--accent-soft)') : hov ? 'var(--surface-hover)' : guest ? 'transparent' : 'var(--surface-card)',
        border: `${selected ? 2 : 1}px solid ${selected ? (guest ? 'var(--inv-deep)' : 'var(--ink)') : guest ? 'var(--inv-line)' : 'var(--border-strong)'}`, borderRadius: guest ? 'var(--radius-lg)' : 'var(--radius-card)', transition: 'var(--transition-control)', ...style }}>
      {icon ? <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 40, height: 40, borderRadius: 'var(--radius-md)', background: selected ? 'var(--ink)' : 'var(--surface-sunken)', color: selected ? 'var(--text-on-dark)' : 'var(--text-secondary)', flex: 'none' }}><Icon name={icon} size={20} /></span> : null}
      <span style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontSize: guest ? 'var(--text-guest-lg)' : 'var(--text-base)', fontWeight: 600, lineHeight: 1.3 }}>{title}</span>
        {description ? <span style={{ fontSize: guest ? 'var(--text-base)' : 'var(--text-sm)', color: 'var(--text-secondary)', lineHeight: 1.45 }}>{description}</span> : null}
      </span>
      {meta ? <span className="num" style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', flex: 'none' }}>{meta}</span> : null}
      <span aria-hidden style={{ width: 24, height: 24, borderRadius: '50%', flex: 'none', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: selected ? (guest ? 'var(--inv-deep)' : 'var(--ink)') : 'transparent', border: selected ? 'none' : '1.5px solid var(--border-strong)', color: '#fff' }}>{selected ? <Icon name="check" size={14} strokeWidth={3} /> : null}</span>
    </button>
  );
}
