−/+ stepper for allowed companions or custom counts.

```jsx
<Stepper value={2} max={6} onChange={setN} format={n => formatNum(n,'ar')} />
```

- `guest` size = 56px targets.
