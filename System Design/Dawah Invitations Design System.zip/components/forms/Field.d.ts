import * as React from 'react';
/** Label/hint/error wrapper for any control. */
export interface FieldProps {
  label?: React.ReactNode;
  hint?: React.ReactNode;
  error?: React.ReactNode;
  required?: boolean;
  optionalLabel?: string;
  htmlFor?: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
export function Field(props: FieldProps): JSX.Element;
