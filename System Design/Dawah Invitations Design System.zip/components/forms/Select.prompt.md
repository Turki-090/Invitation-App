Dropdown for invitation type, language, reminder timing, column mapping.

```jsx
<Select placeholder="نوع الدعوة" value={t} onChange={setT} options={[{value:'single',label:'شخص واحد'},{value:'family',label:'عائلة'},{value:'companions',label:'شخص + مرافقون'}]} />
```

- Chevron sits at inline-end so it flips in RTL automatically.
