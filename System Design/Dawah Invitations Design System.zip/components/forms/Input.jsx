import React, { useState } from 'react';
import { Icon } from '../core/Icon.jsx';
const H = { sm: 'var(--control-h-sm)', md: 'var(--control-h-md)', lg: 'var(--control-h-lg)', guest: 'var(--control-h-guest)' };
export const inputFrame = (focus, invalid, disabled) => ({
  background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)', border: `1px solid ${invalid ? 'var(--danger)' : focus ? 'var(--accent)' : 'var(--border-strong)'}`,
  boxShadow: focus ? (invalid ? '0 0 0 3px rgba(181,83,62,.22)' : 'var(--focus-ring)') : 'none', borderRadius: 'var(--radius-control)', transition: 'var(--transition-control)' });
/** Text input. dir="ltr" + mono for phone numbers / codes (see PhoneInput). */
export function Input({ size = 'md', icon, invalid = false, disabled = false, dir, mono = false, prefix, suffix, style, inputStyle, ...rest }) {
  const [focus, setFocus] = useState(false);
  return (
    <div dir={dir} style={{ display: 'flex', alignItems: 'center', gap: 8, height: H[size] || H.md, padding: '0 12px', color: 'var(--text-body)', ...inputFrame(focus, invalid, disabled), ...style }}>
      {icon ? <Icon name={icon} size={18} color="var(--text-muted)" /> : null}
      {prefix ? <span className={mono ? 'phone' : undefined} style={{ color: 'var(--text-muted)', fontSize: 'var(--text-md)' }}>{prefix}</span> : null}
      <input disabled={disabled} aria-invalid={invalid || undefined} onFocus={e => { setFocus(true); rest.onFocus && rest.onFocus(e); }} onBlur={e => { setFocus(false); rest.onBlur && rest.onBlur(e); }} {...rest}
        style={{ flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent', fontFamily: mono ? 'var(--font-mono)' : 'var(--font-ui)', fontSize: size === 'guest' ? 'var(--text-guest-body)' : size === 'sm' ? 'var(--text-sm)' : 'var(--text-md)', color: 'inherit', boxShadow: 'none', ...inputStyle }} />
      {suffix ? <span style={{ color: 'var(--text-muted)', fontSize: 'var(--text-sm)' }}>{suffix}</span> : null}
    </div>
  );
}
