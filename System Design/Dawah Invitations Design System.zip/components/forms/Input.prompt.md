Text input; base for search, names, OTP codes.

```jsx
<Input icon="search" placeholder="ابحث بالاسم أو الرقم أو العائلة" />
<Input dir="ltr" mono placeholder="0000" size="lg" />
```

- Focus = bronze border + soft ring; invalid = red border.
- Codes/phones: `dir="ltr" mono`.
