import React from 'react';
/** On/off switch (settings, permissions). Knob travels in the reading direction — works natively in RTL. */
export function Switch({ checked = false, onChange, label, description, disabled = false, style }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }}>
      {label ? <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontSize: 'var(--text-md)', fontWeight: 500 }}>{label}</span>
        {description ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{description}</span> : null}
      </span> : null}
      <span style={{ position: 'relative', display: 'inline-flex', flex: 'none', width: 40, height: 24 }}>
        <input type="checkbox" role="switch" checked={checked} disabled={disabled} onChange={e => onChange && onChange(e.target.checked)} style={{ position: 'absolute', inset: 0, opacity: 0, margin: 0, width: '100%', height: '100%', cursor: 'inherit' }} />
        <span aria-hidden style={{ position: 'absolute', inset: 0, borderRadius: 999, background: checked ? 'var(--accepted)' : 'var(--line-strong)', transition: 'var(--transition-control)' }} />
        <span aria-hidden style={{ position: 'absolute', top: 3, insetInlineStart: checked ? 19 : 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 2px rgba(23,20,15,.25)', transition: 'inset-inline-start var(--dur-base) var(--ease-out)' }} />
      </span>
    </label>
  );
}
