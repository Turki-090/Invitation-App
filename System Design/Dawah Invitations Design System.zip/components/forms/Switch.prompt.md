Toggle for RSVP settings, QR pass, auto-reminders and co-host permissions.

```jsx
<Switch checked label="السماح بتغيير الرد" description="حتى موعد إغلاق الردود" onChange={…} />
```

- Green (accepted) when on; knob moves in the reading direction.
