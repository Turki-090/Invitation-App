import * as React from 'react';
/** Radio with label/description. */
export interface RadioProps {
  checked?: boolean;
  onChange?: (value: string) => void;
  name?: string;
  value?: string;
  label?: React.ReactNode;
  description?: React.ReactNode;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export function Radio(props: RadioProps): JSX.Element;
