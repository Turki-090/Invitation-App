import React from 'react';
import { Icon } from '../core/Icon.jsx';
/** Checkbox with label. size="guest" = 28px box + 17px text for family-member selection on the guest page. */
export function Checkbox({ checked = false, indeterminate = false, onChange, label, description, disabled = false, size = 'md', style }) {
  const guest = size === 'guest';
  const box = guest ? 28 : 20;
  const on = checked || indeterminate;
  return (
    <label style={{ display: 'inline-flex', alignItems: description ? 'flex-start' : 'center', gap: guest ? 14 : 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, minHeight: guest ? 'var(--touch-min)' : undefined, ...style }}>
      <span style={{ position: 'relative', display: 'inline-flex', flex: 'none' }}>
        <input type="checkbox" checked={checked} disabled={disabled} onChange={e => onChange && onChange(e.target.checked)} aria-checked={indeterminate ? 'mixed' : checked} style={{ position: 'absolute', inset: 0, opacity: 0, margin: 0, width: '100%', height: '100%', cursor: 'inherit' }} />
        <span aria-hidden style={{ width: box, height: box, borderRadius: guest ? 8 : 'var(--radius-sm)', border: `${guest ? 2 : 1.5}px solid ${on ? (guest ? 'var(--inv-deep)' : 'var(--ink)') : 'var(--border-strong)'}`, background: on ? (guest ? 'var(--inv-deep)' : 'var(--ink)') : 'var(--surface-card)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: '#fff', transition: 'var(--transition-control)' }}>
          {indeterminate ? <Icon name="minus" size={guest ? 18 : 14} strokeWidth={2.5} /> : checked ? <Icon name="check" size={guest ? 18 : 14} strokeWidth={2.5} /> : null}
        </span>
      </span>
      {label ? <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontSize: guest ? 'var(--text-guest-body)' : 'var(--text-md)', fontWeight: guest ? 500 : 400, lineHeight: 1.4 }}>{label}</span>
        {description ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{description}</span> : null}
      </span> : null}
    </label>
  );
}
