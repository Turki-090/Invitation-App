import * as React from 'react';
/** Styled native select. */
export interface SelectProps {
  options: { value: string;
  label: string }[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  size?: 'sm'|'md'|'lg';
  invalid?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export function Select(props: SelectProps): JSX.Element;
