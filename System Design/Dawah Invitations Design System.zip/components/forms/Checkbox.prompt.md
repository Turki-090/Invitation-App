Checkbox for table selection, permissions and (guest size) family-member attendance.

```jsx
<Checkbox size="guest" checked label="عبدالله" onChange={…} />
```

- `indeterminate` for the table header when some rows are selected.
