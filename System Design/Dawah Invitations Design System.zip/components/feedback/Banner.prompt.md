Dashboard attention card: a problem plus the action that fixes it.

```jsx
<Banner kind="danger" title="٣ رسائل فشل إرسالها" actionLabel="مراجعة الرسائل" onAction={…} />
```

- Every banner leads somewhere (actionable-dashboard rule).
