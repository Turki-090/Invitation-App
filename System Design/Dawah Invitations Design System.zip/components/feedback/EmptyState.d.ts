import * as React from 'react';
/** Empty / error / locked state. */
export interface EmptyStateProps {
  icon?: string;
  kind?: 'empty'|'error'|'locked'|'success';
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  secondary?: React.ReactNode;
  compact?: boolean;
  style?: React.CSSProperties;
}
export function EmptyState(props: EmptyStateProps): JSX.Element;
