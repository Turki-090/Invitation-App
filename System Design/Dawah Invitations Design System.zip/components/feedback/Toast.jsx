import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { IconButton } from '../core/IconButton.jsx';
const K = { success: { ic: 'circle-check', c: 'var(--success)' }, error: { ic: 'circle-alert', c: 'var(--danger)' }, warning: { ic: 'triangle-alert', c: 'var(--warning)' }, info: { ic: 'info', c: 'var(--info)' } };
/** Transient confirmation ("تم إرسال ٢٩ دعوة"). Dark ink surface, icon colour carries kind; text always names the outcome. */
export function Toast({ kind = 'success', title, description, action, onDismiss, dismissLabel = 'إغلاق', style }) {
  const k = K[kind] || K.info;
  return (
    <div role="status" style={{ display: 'flex', alignItems: 'flex-start', gap: 12, width: 380, maxWidth: '100%', padding: '12px 14px', background: 'var(--ink)', color: 'var(--text-on-dark)', borderRadius: 'var(--radius-card)', boxShadow: 'var(--shadow-overlay)', ...style }}>
      <Icon name={k.ic} size={20} color={k.c} style={{ marginTop: 1 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 'var(--text-md)', fontWeight: 600, lineHeight: 1.4 }}>{title}</div>
        {description ? <div style={{ fontSize: 'var(--text-sm)', color: 'rgba(251,249,246,.72)', marginTop: 2, lineHeight: 1.5 }}>{description}</div> : null}
        {action ? <div style={{ marginTop: 8 }}>{action}</div> : null}
      </div>
      {onDismiss ? <IconButton name="x" label={dismissLabel} size="sm" onClick={onDismiss} style={{ color: 'rgba(251,249,246,.7)', margin: '-6px -6px -6px 0' }} /> : null}
    </div>
  );
}
