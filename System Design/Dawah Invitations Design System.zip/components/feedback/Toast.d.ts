import * as React from 'react';
/** Transient result message. */
export interface ToastProps {
  kind?: 'success'|'error'|'warning'|'info';
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  onDismiss?: () => void;
  dismissLabel?: string;
  style?: React.CSSProperties;
}
export function Toast(props: ToastProps): JSX.Element;
