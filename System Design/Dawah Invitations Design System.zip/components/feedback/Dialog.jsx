import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { IconButton } from '../core/IconButton.jsx';
/** Modal dialog. `inline` renders the panel without the fixed scrim (for specimens/embedding). danger=true for destructive confirmations. */
export function Dialog({ open = true, title, description, children, actions, onClose, closeLabel = 'إغلاق', danger = false, width = 480, inline = false, style }) {
  if (!open) return null;
  const panel = (
    <div role="dialog" aria-modal={!inline} aria-labelledby="dawah-dialog-title" style={{ width: '100%', maxWidth: width, background: 'var(--surface-card)', borderRadius: 'var(--radius-dialog)', boxShadow: inline ? 'var(--shadow-raised)' : 'var(--shadow-overlay)', border: '1px solid var(--border-default)', overflow: 'hidden', ...style }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, padding: '20px 20px 0' }}>
        {danger ? <span style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--danger-bg)', color: 'var(--danger-fg)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Icon name="triangle-alert" size={20} /></span> : null}
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 id="dawah-dialog-title" style={{ margin: 0, fontSize: 'var(--text-lg)', fontWeight: 600, lineHeight: 1.35 }}>{title}</h2>
          {description ? <p style={{ margin: '6px 0 0', fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 1.55 }}>{description}</p> : null}
        </div>
        {onClose ? <IconButton name="x" label={closeLabel} size="sm" onClick={onClose} /> : null}
      </div>
      {children ? <div style={{ padding: '16px 20px 0' }}>{children}</div> : null}
      {actions ? <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: 20 }}>{actions}</div> : <div style={{ height: 20 }} />}
    </div>
  );
  if (inline) return panel;
  return <div onClick={e => { if (e.target === e.currentTarget && onClose) onClose(); }} style={{ position: 'fixed', inset: 0, background: 'var(--scrim)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, zIndex: 100 }}>{panel}</div>;
}
