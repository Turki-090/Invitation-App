Shimmering placeholder block for loading tables and cards.

```jsx
<Skeleton width={160} height={14} />
```

- Match the shape of the content it replaces.
