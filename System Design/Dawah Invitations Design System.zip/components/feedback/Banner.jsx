import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Button } from '../core/Button.jsx';
const K = { danger: { ic: 'circle-alert', c: 'var(--danger)', bg: 'var(--danger-bg)', fg: 'var(--danger-fg)' }, warning: { ic: 'clock', c: 'var(--warning)', bg: 'var(--warning-bg)', fg: 'var(--warning-fg)' }, info: { ic: 'info', c: 'var(--info)', bg: 'var(--info-bg)', fg: 'var(--info-fg)' }, success: { ic: 'circle-check', c: 'var(--success)', bg: 'var(--success-bg)', fg: 'var(--success-fg)' }, neutral: { ic: 'info', c: 'var(--text-muted)', bg: 'var(--surface-sunken)', fg: 'var(--text-secondary)' } };
/** Actionable attention card ("٣ رسائل فشل إرسالها → مراجعة"). Every banner leads somewhere: actionLabel is required in practice. */
export function Banner({ kind = 'info', icon, title, description, actionLabel, onAction, secondaryLabel, onSecondary, compact = false, style }) {
  const k = K[kind] || K.info;
  return (
    <div role={kind === 'danger' ? 'alert' : 'status'} style={{ display: 'flex', alignItems: compact ? 'center' : 'flex-start', gap: 12, padding: compact ? '10px 14px' : '14px 16px', background: 'var(--surface-card)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-card)', boxShadow: 'var(--shadow-card)', ...style }}>
      <span style={{ width: 36, height: 36, borderRadius: 'var(--radius-md)', background: k.bg, color: k.c, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Icon name={icon || k.ic} size={18} /></span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 'var(--text-md)', fontWeight: 600, lineHeight: 1.4 }}>{title}</div>
        {description && !compact ? <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', marginTop: 2, lineHeight: 1.5 }}>{description}</div> : null}
      </div>
      {(actionLabel || secondaryLabel) ? <div style={{ display: 'flex', gap: 6, flex: 'none', alignItems: 'center' }}>
        {secondaryLabel ? <Button variant="ghost" size="sm" onClick={onSecondary}>{secondaryLabel}</Button> : null}
        {actionLabel ? <Button variant="secondary" size="sm" iconEnd="arrow-left" onClick={onAction}>{actionLabel}</Button> : null}
      </div> : null}
    </div>
  );
}
