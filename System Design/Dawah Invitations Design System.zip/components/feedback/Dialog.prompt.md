Confirmation and form dialog — protects hosts before high-impact actions (send 400 invitations, delete responded guest).

```jsx
<Dialog title="إرسال ٤٠٠ دعوة الآن؟" description="سيتم استخدام ٤٠٠ رصيد." actions={<><Button variant="secondary">إلغاء</Button><Button>إرسال الآن</Button></>} onClose={close} />
```

- `danger` adds the warning disc; pair with `Button variant="danger"`.
