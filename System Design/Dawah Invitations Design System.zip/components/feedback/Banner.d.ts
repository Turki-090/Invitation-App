import * as React from 'react';
/** Actionable attention card. */
export interface BannerProps {
  kind?: 'danger'|'warning'|'info'|'success'|'neutral';
  icon?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  secondaryLabel?: string;
  onSecondary?: () => void;
  compact?: boolean;
  style?: React.CSSProperties;
}
export function Banner(props: BannerProps): JSX.Element;
