import * as React from 'react';
/** Modal dialog; danger for destructive confirmations.
 * @startingPoint section="Feedback" subtitle="Dialog, toast, attention banner, empty states" viewport="700x420" */
export interface DialogProps {
  open?: boolean;
  title: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  actions?: React.ReactNode;
  onClose?: () => void;
  closeLabel?: string;
  danger?: boolean;
  width?: number;
  /** render panel without scrim */ inline?: boolean;
  style?: React.CSSProperties;
}
export function Dialog(props: DialogProps): JSX.Element;
