import React from 'react';
import { Icon } from '../core/Icon.jsx';
/** Empty / error / permission-restricted state. kind changes the icon disc tone only — copy explains what to do next. */
export function EmptyState({ icon = 'inbox', kind = 'empty', title, description, action, secondary, compact = false, style }) {
  const tone = { empty: { bg: 'var(--surface-sunken)', c: 'var(--text-muted)' }, error: { bg: 'var(--danger-bg)', c: 'var(--danger)' }, locked: { bg: 'var(--warning-bg)', c: 'var(--warning)' }, success: { bg: 'var(--success-bg)', c: 'var(--success)' } }[kind] || {};
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: compact ? '24px 16px' : '48px 24px', gap: 6, ...style }}>
      <span style={{ width: compact ? 44 : 56, height: compact ? 44 : 56, borderRadius: '50%', background: tone.bg, color: tone.c, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}><Icon name={kind === 'error' ? 'circle-alert' : kind === 'locked' ? 'lock' : icon} size={compact ? 20 : 24} /></span>
      <div style={{ fontSize: compact ? 'var(--text-md)' : 'var(--text-lg)', fontWeight: 600 }}>{title}</div>
      {description ? <p style={{ margin: 0, maxWidth: 380, fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{description}</p> : null}
      {(action || secondary) ? <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>{secondary}{action}</div> : null}
    </div>
  );
}
