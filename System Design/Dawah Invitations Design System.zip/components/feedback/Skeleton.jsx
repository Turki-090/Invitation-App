import React from 'react';
/** Loading placeholder block. Use rows of Skeleton in tables/cards; never a spinner for page content. */
export function Skeleton({ width = '100%', height = 14, radius = 'var(--radius-sm)', style }) {
  return (
    <span aria-hidden style={{ display: 'block', width, height, borderRadius: radius, background: 'linear-gradient(90deg,var(--surface-sunken) 25%,var(--surface-pressed) 50%,var(--surface-sunken) 75%)', backgroundSize: '400% 100%', animation: 'dawah-shimmer 1.4s ease-in-out infinite', ...style }}>
      <style>{'@keyframes dawah-shimmer{0%{background-position:100% 0}100%{background-position:0 0}}'}</style>
    </span>
  );
}
