Empty, error and permission-restricted states for lists and pages.

```jsx
<EmptyState icon="users" title="لا يوجد ضيوف بعد" description="أضف الضيوف يدويًا أو استورد ملف Excel." action={<Button icon="plus">إضافة ضيف</Button>} />
```

- `kind="locked"` for insufficient permissions; `error` for network/system errors with a retry action.
