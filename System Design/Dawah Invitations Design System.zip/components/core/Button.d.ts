import * as React from 'react';
/** Action button. variant primary (ink) is the default; accent (bronze) is for the single most important CTA on a screen.
 * @startingPoint section="Core" subtitle="Ink primary, bronze accent, guest sizes" viewport="700x360" */
export interface ButtonProps {
  variant?: 'primary'|'accent'|'secondary'|'ghost'|'danger'|'danger-soft'|'whatsapp'|'guest-primary'|'guest-secondary';
  size?: 'sm'|'md'|'lg'|'guest';
  icon?: string;
  iconEnd?: string;
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  children?: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
