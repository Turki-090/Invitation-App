import * as React from 'react';
/** Initials disc for hosts/co-hosts. */
export interface AvatarProps {
  name: string;
  src?: string;
  size?: 'xs'|'sm'|'md'|'lg'|'xl';
  tone?: 'soft'|'dark';
  style?: React.CSSProperties;
}
export function Avatar(props: AvatarProps): JSX.Element;
