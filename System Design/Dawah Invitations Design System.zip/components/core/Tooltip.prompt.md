Short explanatory tooltip for icon buttons and truncated values.

```jsx
<Tooltip label="إعادة الإرسال"><IconButton name="refresh-cw" label="إعادة الإرسال" /></Tooltip>
```

- Never hide required information in a tooltip; guests never see tooltips.
