import * as React from 'react';
/** Guest category chip. */
export interface TagProps {
  children: React.ReactNode;
  tone?: 'neutral'|'outline'|'accent';
  onRemove?: () => void;
  removeLabel?: string;
  size?: 'sm'|'md';
  style?: React.CSSProperties;
}
export function Tag(props: TagProps): JSX.Element;
