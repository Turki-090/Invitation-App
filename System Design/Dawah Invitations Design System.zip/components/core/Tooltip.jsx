import React, { useState } from 'react';
/** Dark ink tooltip on hover/focus. placement top|bottom. */
export function Tooltip({ label, children, placement = 'top', open }) {
  const [hov, setHov] = useState(false);
  const show = open ?? hov;
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)} onFocus={() => setHov(true)} onBlur={() => setHov(false)}>
      {children}
      <span role="tooltip" style={{ position: 'absolute', insetInlineStart: '50%', transform: 'translateX(-50%)', [placement === 'top' ? 'bottom' : 'top']: 'calc(100% + 6px)', background: 'var(--ink)', color: 'var(--text-on-dark)', fontSize: 'var(--text-xs)', fontWeight: 500, lineHeight: 1.4, padding: '6px 10px', borderRadius: 'var(--radius-sm)', whiteSpace: 'nowrap', pointerEvents: 'none', opacity: show ? 1 : 0, transition: 'opacity var(--dur-fast) var(--ease-out)', zIndex: 20, boxShadow: 'var(--shadow-raised)' }}>{label}</span>
    </span>
  );
}
