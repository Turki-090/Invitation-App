import * as React from 'react';
/** Container surface. tone default (white) | sunken | accent (bronze tint) | dark.
 * @startingPoint section="Core" subtitle="White surface on paper, 1px warm border" viewport="700x300" */
export interface CardProps {
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  footer?: React.ReactNode;
  padding?: string|number;
  tone?: 'default'|'sunken'|'accent'|'dark';
  interactive?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export function Card(props: CardProps): JSX.Element;
