import React, { useState } from 'react';
import { Icon } from './Icon.jsx';
const SZ = { sm: 32, md: 40, lg: 48 };
export function IconButton({ name, label, variant = 'ghost', size = 'md', active = false, disabled = false, flipRtl = false, badge, style, ...rest }) {
  const [hov, setHov] = useState(false);
  const px = SZ[size] || SZ.md;
  const outline = variant === 'outline';
  return (
    <button type="button" aria-label={label} title={label} disabled={disabled} aria-pressed={active || undefined}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: px, height: px, flex: 'none',
        background: active ? 'var(--accent-soft)' : hov ? 'var(--surface-hover)' : outline ? 'var(--surface-card)' : 'transparent',
        color: active ? 'var(--accent-hover)' : 'var(--text-secondary)', border: `1px solid ${outline ? 'var(--border-strong)' : 'transparent'}`,
        borderRadius: 'var(--radius-control)', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, transition: 'var(--transition-control)', ...style }} {...rest}>
      <Icon name={name} size={px >= 48 ? 22 : 18} flipRtl={flipRtl} />
      {badge != null ? <span style={{ position: 'absolute', top: 6, insetInlineEnd: 6, minWidth: 8, height: 8, borderRadius: 999, background: 'var(--danger)', border: '2px solid var(--surface-card)' }} /> : null}
    </button>
  );
}
