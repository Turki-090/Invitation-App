import React, { useState } from 'react';
import { Icon } from './Icon.jsx';
const V = {
  primary: { bg: 'var(--ink)', fg: 'var(--text-on-dark)', bd: 'var(--ink)', hbg: '#2B261F', abg: '#3A342B' },
  accent: { bg: 'var(--accent)', fg: 'var(--text-on-accent)', bd: 'var(--accent)', hbg: 'var(--accent-hover)', abg: '#6A4F2A' },
  secondary: { bg: 'var(--surface-card)', fg: 'var(--text-body)', bd: 'var(--border-strong)', hbg: 'var(--surface-hover)', abg: 'var(--surface-pressed)' },
  ghost: { bg: 'transparent', fg: 'var(--text-secondary)', bd: 'transparent', hbg: 'var(--surface-hover)', abg: 'var(--surface-pressed)' },
  danger: { bg: 'var(--danger)', fg: '#fff', bd: 'var(--danger)', hbg: '#9A4331', abg: '#7F3527' },
  'danger-soft': { bg: 'var(--danger-bg)', fg: 'var(--danger-fg)', bd: 'var(--danger-bg)', hbg: '#F1D8D2', abg: '#EAC9C1' },
  whatsapp: { bg: 'var(--wa-teal)', fg: '#fff', bd: 'var(--wa-teal)', hbg: '#0F7A6E', abg: '#0B6259' },
  'guest-primary': { bg: 'var(--inv-deep)', fg: 'var(--inv-cream)', bd: 'var(--inv-deep)', hbg: 'var(--inv-deep-2)', abg: '#1E1710' },
  'guest-secondary': { bg: 'transparent', fg: 'var(--inv-deep)', bd: 'var(--inv-line)', hbg: 'rgba(154,118,66,.08)', abg: 'rgba(154,118,66,.14)' },
};
const S = {
  sm: { h: 'var(--control-h-sm)', px: 12, fs: 'var(--text-sm)', gap: 6, ic: 16 },
  md: { h: 'var(--control-h-md)', px: 16, fs: 'var(--text-md)', gap: 8, ic: 18 },
  lg: { h: 'var(--control-h-lg)', px: 20, fs: 'var(--text-base)', gap: 8, ic: 20 },
  guest: { h: 'var(--control-h-guest)', px: 24, fs: 'var(--text-guest-lg)', gap: 12, ic: 24 },
};
export function Button({ variant = 'primary', size = 'md', icon, iconEnd, loading = false, disabled = false, fullWidth = false, children, style, ...rest }) {
  const [hov, setHov] = useState(false); const [act, setAct] = useState(false);
  const v = V[variant] || V.primary; const s = S[size] || S.md;
  const off = disabled || loading;
  const isGuest = variant.startsWith('guest');
  return (
    <button type="button" disabled={off} aria-busy={loading || undefined}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setAct(false); }} onMouseDown={() => setAct(true)} onMouseUp={() => setAct(false)}
      style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: s.gap, height: s.h, padding: `0 ${s.px}px`, width: fullWidth ? '100%' : undefined,
        fontFamily: 'var(--font-ui)', fontSize: s.fs, fontWeight: isGuest ? 600 : 500, lineHeight: 1, whiteSpace: 'nowrap',
        background: act ? v.abg : hov ? v.hbg : v.bg, color: v.fg, border: `1px solid ${act || hov ? (v.bd === 'transparent' ? 'transparent' : v.bd) : v.bd}`,
        borderRadius: isGuest ? 'var(--radius-lg)' : 'var(--radius-control)', cursor: off ? 'not-allowed' : 'pointer', opacity: off ? .5 : 1,
        transition: 'var(--transition-control)', ...style }} {...rest}>
      {loading ? <Icon name="loader-circle" size={s.ic} style={{ animation: 'dawah-spin 1s linear infinite' }} /> : icon ? <Icon name={icon} size={s.ic} /> : null}
      {children ? <span>{children}</span> : null}
      {iconEnd ? <Icon name={iconEnd} size={s.ic} flipRtl /> : null}
      <style>{'@keyframes dawah-spin{to{transform:rotate(360deg)}}'}</style>
    </button>
  );
}
