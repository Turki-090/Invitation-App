Standard dashboard surface — white card with 1px warm border and 14px radius; header/footer slots.

```jsx
<Card title="نسبة الردود" subtitle="آخر تحديث قبل ٣ دقائق" actions={<IconButton name="ellipsis" label="المزيد" />}>…</Card>
```

- `tone="dark"` for the event-day hero; `accent` sparingly (WhatsApp connection status, credits).
