Category/tag chip for guests and active filters.

```jsx
<Tag>أهل العروس</Tag>
<Tag tone="accent" onRemove={clear}>مقبولة</Tag>
```

- Removable tags render an ✕ with an accessible label.
