import * as React from 'react';
/** Ink tooltip on hover/focus. */
export interface TooltipProps {
  label: React.ReactNode;
  children: React.ReactNode;
  placement?: 'top'|'bottom';
  open?: boolean;
}
export function Tooltip(props: TooltipProps): JSX.Element;
