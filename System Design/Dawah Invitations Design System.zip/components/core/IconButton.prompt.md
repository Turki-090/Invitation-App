Icon-only button for toolbars, table row actions and top-bar controls.

```jsx
<IconButton name="bell" label="التنبيهات" badge />
<IconButton name="ellipsis" label="المزيد" variant="outline" size="sm" />
```

- `label` is mandatory (aria-label + title).
- `badge` renders a small red dot (notifications).
