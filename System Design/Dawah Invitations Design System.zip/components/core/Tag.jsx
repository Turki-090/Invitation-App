import React from 'react';
import { Icon } from './Icon.jsx';
/** Category/tag chip for guests (e.g. "أهل العروس", "زملاء العمل"). Neutral by default; tone=accent for the active filter. */
export function Tag({ children, tone = 'neutral', onRemove, removeLabel = 'إزالة', size = 'md', style }) {
  const tones = { neutral: { bg: 'var(--surface-sunken)', fg: 'var(--text-secondary)', bd: 'transparent' }, outline: { bg: 'transparent', fg: 'var(--text-secondary)', bd: 'var(--border-strong)' }, accent: { bg: 'var(--accent-soft)', fg: 'var(--accent-hover)', bd: 'transparent' } };
  const t = tones[tone] || tones.neutral;
  const h = size === 'sm' ? 22 : 28;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: h, padding: `0 ${size === 'sm' ? 8 : 10}px`, borderRadius: 'var(--radius-pill)', background: t.bg, color: t.fg, border: `1px solid ${t.bd}`, fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)', fontWeight: 500, lineHeight: 1, whiteSpace: 'nowrap', ...style }}>
      {children}
      {onRemove ? <button type="button" aria-label={removeLabel} onClick={onRemove} style={{ display: 'inline-flex', border: 0, background: 'transparent', padding: 0, marginInlineEnd: -4, cursor: 'pointer', color: 'inherit', opacity: .7 }}><Icon name="x" size={14} /></button> : null}
    </span>
  );
}
