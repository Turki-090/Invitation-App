import React, { useEffect, useRef, useState } from 'react';
const toPascal = s => String(s).split('-').map(p => p.charAt(0).toUpperCase() + p.slice(1)).join('');
/** Lucide icon (loaded from CDN as window.lucide). Directional icons pass flipRtl to mirror inside RTL containers. */
export function Icon({ name, size = 18, strokeWidth = 1.75, color = 'currentColor', label, flipRtl = false, style, ...rest }) {
  const ref = useRef(null);
  const [rtl, setRtl] = useState(false);
  useEffect(() => { if (!flipRtl || !ref.current) return; const el = ref.current.closest('[dir]'); setRtl(!!el && el.getAttribute('dir') === 'rtl'); }, [flipRtl]);
  const lib = typeof window !== 'undefined' ? window.lucide : null;
  const P = toPascal(name);
  const node = lib ? (lib.icons && lib.icons[P]) || lib[P] : null;
  const kids = Array.isArray(node) ? node.map(([tag, attrs], i) => React.createElement(tag, { ...attrs, key: i })) : null;
  return (
    <svg ref={ref} xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true}
      style={{ flex: 'none', display: 'inline-block', verticalAlign: 'middle', transform: rtl ? 'scaleX(-1)' : undefined, ...style }} {...rest}>{kids}</svg>
  );
}
