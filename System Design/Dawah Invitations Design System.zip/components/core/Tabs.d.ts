import * as React from 'react';
/** Status filter tabs with optional counts. */
export interface TabsProps {
  items: { id: string;
  label: React.ReactNode;
  count?: number|string }[];
  value: string;
  onChange?: (id: string) => void;
  variant?: 'underline'|'pill';
  style?: React.CSSProperties;
}
export function Tabs(props: TabsProps): JSX.Element;
