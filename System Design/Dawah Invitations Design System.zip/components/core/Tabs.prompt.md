Filter tabs (All / Accepted / Partial / Declined / Pending / Not sent…) with counts.

```jsx
<Tabs value={tab} onChange={setTab} items={[{id:'all',label:'الكل',count:450},{id:'accepted',label:'تم القبول',count:280}]} />
```

- `underline` for page-level filters; `pill` inside cards (e.g. WhatsApp preview type switcher).
