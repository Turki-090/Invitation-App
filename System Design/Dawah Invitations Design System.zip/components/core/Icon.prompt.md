Renders a Lucide icon by kebab-case name; use for every glyph in the system (no emoji, no hand-drawn SVG).

```jsx
<Icon name="send" size={18} />
<Icon name="arrow-left" flipRtl />
```

- Requires `<script src="https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js">` on the page.
- `flipRtl` mirrors directional icons when an ancestor has `dir="rtl"`.
- Decorative by default (aria-hidden); pass `label` when the icon stands alone.
