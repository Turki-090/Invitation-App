Initials avatar for hosts, co-hosts and activity items.

```jsx
<Avatar name="خالد العمري" />
<Avatar name="Noura" size="lg" tone="dark" />
```

- Bronze-tint background by default; `dark` for the current user in the sidebar.
