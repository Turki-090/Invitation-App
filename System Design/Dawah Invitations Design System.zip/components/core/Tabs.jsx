import React from 'react';
/** Status filter tabs. items: [{id,label,count}]. variant underline (page-level) or pill (in-card). */
export function Tabs({ items = [], value, onChange, variant = 'underline', style }) {
  const pill = variant === 'pill';
  return (
    <div role="tablist" style={{ display: 'flex', gap: pill ? 4 : 2, borderBottom: pill ? 'none' : '1px solid var(--border-default)', padding: pill ? 4 : 0, background: pill ? 'var(--surface-sunken)' : 'transparent', borderRadius: pill ? 'var(--radius-control)' : 0, overflowX: 'auto', ...style }}>
      {items.map(it => {
        const on = it.id === value;
        return (
          <button key={it.id} role="tab" type="button" aria-selected={on} onClick={() => onChange && onChange(it.id)}
            style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: pill ? 32 : 40, padding: pill ? '0 12px' : '0 12px', border: 0, background: pill && on ? 'var(--surface-card)' : 'transparent', color: on ? 'var(--text-body)' : 'var(--text-muted)', fontSize: 'var(--text-md)', fontWeight: on ? 600 : 500, cursor: 'pointer', whiteSpace: 'nowrap',
              borderRadius: pill ? 'var(--radius-sm)' : 0, boxShadow: pill && on ? 'var(--shadow-card)' : 'none', borderBottom: pill ? 'none' : `2px solid ${on ? 'var(--ink)' : 'transparent'}`, marginBottom: pill ? 0 : -1, transition: 'var(--transition-control)' }}>
            {it.label}
            {it.count != null ? <span className="num" style={{ fontSize: 'var(--text-xs)', fontWeight: 600, padding: '1px 6px', borderRadius: 999, background: on ? 'var(--ink)' : 'var(--surface-sunken)', color: on ? 'var(--text-on-dark)' : 'var(--text-muted)' }}>{it.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
