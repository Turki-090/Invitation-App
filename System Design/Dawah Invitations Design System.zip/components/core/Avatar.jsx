import React from 'react';
const SZ = { xs: 24, sm: 28, md: 36, lg: 44, xl: 56 };
const initials = n => String(n || '').trim().split(/\s+/).slice(0, 2).map(w => w.charAt(0)).join('');
/** Soft bronze-tint disc with initials; pass src for a photo. */
export function Avatar({ name, src, size = 'md', tone = 'soft', style }) {
  const px = SZ[size] || SZ.md;
  const dark = tone === 'dark';
  return (
    <span role="img" aria-label={name} style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: px, height: px, flex: 'none', borderRadius: 'var(--radius-full)', overflow: 'hidden',
      background: dark ? 'var(--ink)' : 'var(--accent-soft)', color: dark ? 'var(--text-on-dark)' : 'var(--accent-hover)', fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: Math.round(px * .38), lineHeight: 1, ...style }}>
      {src ? <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : initials(name)}
    </span>
  );
}
