import * as React from 'react';
/** Lucide icon by kebab-case name (window.lucide from CDN). */
export interface IconProps {
  name: string;
  size?: number;
  strokeWidth?: number;
  color?: string;
  label?: string;
  /** mirror inside RTL containers (arrows, chevrons) */ flipRtl?: boolean;
  style?: React.CSSProperties;
}
export function Icon(props: IconProps): JSX.Element;
