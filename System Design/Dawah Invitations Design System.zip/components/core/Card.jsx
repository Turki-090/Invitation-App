import React from 'react';
/** White surface on paper: 1px warm border, 14px radius, whisper shadow. Header optional. */
export function Card({ title, subtitle, actions, footer, padding = 'var(--card-pad)', tone = 'default', interactive = false, children, style, ...rest }) {
  const tones = { default: { bg: 'var(--surface-card)', bd: 'var(--border-default)' }, sunken: { bg: 'var(--surface-sunken)', bd: 'transparent' }, accent: { bg: 'var(--accent-soft)', bd: 'var(--accent-soft-2)' }, dark: { bg: 'var(--ink)', bd: 'var(--ink)' } };
  const t = tones[tone] || tones.default;
  return (
    <section style={{ background: t.bg, color: tone === 'dark' ? 'var(--text-on-dark)' : 'inherit', border: `1px solid ${t.bd}`, borderRadius: 'var(--radius-card)', boxShadow: tone === 'default' ? 'var(--shadow-card)' : 'none', display: 'flex', flexDirection: 'column', cursor: interactive ? 'pointer' : undefined, transition: 'var(--transition-control)', ...style }} {...rest}>
      {(title || actions) ? (
        <header style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, padding: `${padding} ${padding} 0` }}>
          <div style={{ minWidth: 0 }}>
            {title ? <h3 style={{ margin: 0, fontSize: 'var(--text-base)', fontWeight: 600, lineHeight: 1.4 }}>{title}</h3> : null}
            {subtitle ? <p style={{ margin: '2px 0 0', fontSize: 'var(--text-sm)', color: tone === 'dark' ? 'rgba(251,249,246,.7)' : 'var(--text-muted)' }}>{subtitle}</p> : null}
          </div>
          {actions ? <div style={{ display: 'flex', gap: 8, flex: 'none' }}>{actions}</div> : null}
        </header>) : null}
      <div style={{ padding, flex: 1 }}>{children}</div>
      {footer ? <footer style={{ padding: `12px ${padding}`, borderTop: `1px solid ${tone === 'dark' ? 'rgba(255,255,255,.12)' : 'var(--border-default)'}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>{footer}</footer> : null}
    </section>
  );
}
