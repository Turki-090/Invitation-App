import * as React from 'react';
/** Square icon-only button; label is required for accessibility. */
export interface IconButtonProps {
  name: string;
  label: string;
  variant?: 'ghost'|'outline';
  size?: 'sm'|'md'|'lg';
  active?: boolean;
  disabled?: boolean;
  flipRtl?: boolean;
  /** show a red dot */ badge?: boolean|number;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function IconButton(props: IconButtonProps): JSX.Element;
