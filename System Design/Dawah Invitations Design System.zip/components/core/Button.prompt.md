Primary action control for host dashboard and guest pages; ink is the default, bronze accent is reserved for one key CTA per screen.

```jsx
<Button icon="send">إرسال الدعوات</Button>
<Button variant="secondary" size="sm">إلغاء</Button>
<Button variant="guest-primary" size="guest" fullWidth>سأحضر</Button>
```

- `guest` size = 60px tall for elderly-friendly RSVP buttons; stack them, never side-by-side.
- `danger` for destructive confirms; `whatsapp` only for "Open in WhatsApp".
- `iconEnd` auto-mirrors in RTL.
