import React from 'react';
import { formatNum, formatPercent } from './Num.jsx';
/** Segmented RSVP progress. segments: [{label, value, tone}] — tone is a status token name (accepted/partial/declined/pending/notsent). Legend always shows label + percent + count. */
export function ProgressBar({ segments = [], total, lang = 'ar', height = 10, legend = true, style }) {
  const sum = total || segments.reduce((a, s) => a + (s.value || 0), 0) || 1;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, ...style }}>
      <div role="img" aria-label={segments.map(s => `${s.label} ${formatPercent(Math.round(s.value / sum * 100), lang)}`).join(', ')} style={{ display: 'flex', height, borderRadius: 'var(--radius-pill)', overflow: 'hidden', background: 'var(--surface-sunken)', gap: 2 }}>
        {segments.map((s, i) => <span key={i} style={{ width: `${(s.value / sum) * 100}%`, background: `var(--${s.tone || 'notsent'})`, transition: 'width var(--dur-slow) var(--ease-out)' }} />)}
      </div>
      {legend ? <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px 20px' }}>
        {segments.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 'var(--text-sm)' }}>
            <span aria-hidden style={{ width: 10, height: 10, borderRadius: 3, background: `var(--${s.tone || 'notsent'})` }} />
            <span style={{ color: 'var(--text-secondary)' }}>{s.label}</span>
            <span className="num" style={{ fontWeight: 600 }}>{formatPercent(Math.round(s.value / sum * 100), lang)}</span>
            <span className="num" style={{ color: 'var(--text-muted)' }}>({formatNum(s.value, lang)})</span>
          </div>))}
      </div> : null}
    </div>
  );
}
