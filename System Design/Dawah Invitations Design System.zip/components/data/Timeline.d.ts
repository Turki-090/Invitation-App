import * as React from 'react';
/** Delivery/activity timeline. */
export interface TimelineProps {
  items: { label: React.ReactNode;
  time?: string;
  tone?: string;
  icon?: string;
  meta?: React.ReactNode;
  hollow?: boolean;
  strong?: boolean }[];
  dense?: boolean;
  style?: React.CSSProperties;
}
export function Timeline(props: TimelineProps): JSX.Element;
