import React, { useState } from 'react';
import { Checkbox } from '../forms/Checkbox.jsx';
/** Data table for guest lists. columns: [{key, header, width, align, render(row)}]. Selectable rows use the row key; header checkbox toggles all. Text aligns to reading start; numbers use align:'end'. */
export function Table({ columns = [], rows = [], rowKey = 'id', selectable = false, selected = [], onSelect, onRowClick, dense = false, emptyState, selectAllLabel = 'تحديد الكل', style }) {
  const [hov, setHov] = useState(null);
  const allOn = rows.length > 0 && rows.every(r => selected.includes(r[rowKey]));
  const someOn = !allOn && rows.some(r => selected.includes(r[rowKey]));
  const toggleAll = () => onSelect && onSelect(allOn ? [] : rows.map(r => r[rowKey]));
  const toggle = id => onSelect && onSelect(selected.includes(id) ? selected.filter(x => x !== id) : [...selected, id]);
  const pad = dense ? '8px 12px' : '12px 14px';
  const th = { textAlign: 'start', padding: pad, fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--text-muted)', borderBottom: '1px solid var(--border-default)', background: 'var(--surface-sunken)', whiteSpace: 'nowrap', position: 'sticky', top: 0, zIndex: 1 };
  return (
    <div style={{ overflowX: 'auto', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-card)', background: 'var(--surface-card)', boxShadow: 'var(--shadow-card)', ...style }}>
      <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0, fontSize: 'var(--text-md)' }}>
        <thead><tr>
          {selectable ? <th style={{ ...th, width: 44 }}><Checkbox checked={allOn} indeterminate={someOn} onChange={toggleAll} /><span style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>{selectAllLabel}</span></th> : null}
          {columns.map(c => <th key={c.key} style={{ ...th, width: c.width, textAlign: c.align || 'start' }}>{c.header}</th>)}
        </tr></thead>
        <tbody>
          {rows.length === 0 && emptyState ? <tr><td colSpan={columns.length + (selectable ? 1 : 0)} style={{ padding: 0 }}>{emptyState}</td></tr> : null}
          {rows.map((r, i) => {
            const id = r[rowKey]; const on = selected.includes(id);
            return (
              <tr key={id ?? i} onClick={onRowClick ? () => onRowClick(r) : undefined} onMouseEnter={() => setHov(id)} onMouseLeave={() => setHov(null)}
                style={{ background: on ? 'var(--accent-soft)' : hov === id ? 'var(--surface-hover)' : 'transparent', cursor: onRowClick ? 'pointer' : 'default', transition: 'background-color var(--dur-fast)' }}>
                {selectable ? <td onClick={e => e.stopPropagation()} style={{ padding: pad, borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none', width: 44 }}><Checkbox checked={on} onChange={() => toggle(id)} /></td> : null}
                {columns.map(c => <td key={c.key} style={{ padding: pad, borderBottom: i < rows.length - 1 ? '1px solid var(--border-default)' : 'none', textAlign: c.align || 'start', verticalAlign: 'middle', whiteSpace: c.wrap ? 'normal' : 'nowrap' }}>{c.render ? c.render(r) : r[c.key]}</td>)}
              </tr>);
          })}
        </tbody>
      </table>
    </div>
  );
}
