import * as React from 'react';
/** LTR mono phone number, optional masking. */
export interface PhoneProps {
  value: string;
  masked?: boolean;
  style?: React.CSSProperties;
}
export function Phone(props: PhoneProps): JSX.Element;
