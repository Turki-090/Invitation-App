import React from 'react';
/** WhatsApp number — always LTR, Western digits, mono, tabular. masked=true hides the middle for users without "view full numbers" permission. */
export function Phone({ value, masked = false, style }) {
  const v = String(value || '');
  const shown = masked ? v.replace(/^(\+?\d{3,4})\d+(\d{3})$/, (_, a, b) => `${a} ••• •• ${b}`) : v.replace(/^(\+\d{3})(\d{2})(\d{3})(\d{4})$/, '$1 $2 $3 $4');
  return <span className="phone" dir="ltr" style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', ...style }}>{shown}</span>;
}
