import * as React from 'react';
/** Localised number (Arabic-Indic in ar). */
export interface NumProps {
  value: number;
  lang?: 'ar'|'en';
  percent?: boolean;
  style?: React.CSSProperties;
}
export function Num(props: NumProps): JSX.Element;
