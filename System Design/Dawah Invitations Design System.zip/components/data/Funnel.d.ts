import * as React from 'react';
/** Sent → Delivered → Read → Responded. */
export interface FunnelProps {
  steps: { label: string;
  value: number }[];
  lang?: 'ar'|'en';
  style?: React.CSSProperties;
}
export function Funnel(props: FunnelProps): JSX.Element;
