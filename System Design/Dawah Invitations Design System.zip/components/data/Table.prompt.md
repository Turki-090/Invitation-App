Guest list table: sticky header, row selection for bulk actions, hover, custom cell renderers.

```jsx
<Table selectable selected={sel} onSelect={setSel} rowKey="id" columns={cols} rows={guests} onRowClick={openGuest} />
```

- Cells align to reading start; numeric columns pass `align:"end"`.
- Below ~900px switch to stacked cards (see Host dashboard kit).
