import * as React from 'react';
/** Overview metric with unit context. */
export interface StatCardProps {
  label: React.ReactNode;
  value: number|string;
  /** unit: "مجموعة دعوات" / "شخص متوقع" */ context?: React.ReactNode;
  footnote?: React.ReactNode;
  tone?: string;
  icon?: string;
  lang?: 'ar'|'en';
  onClick?: () => void;
  size?: 'md'|'lg';
  style?: React.CSSProperties;
}
export function StatCard(props: StatCardProps): JSX.Element;
