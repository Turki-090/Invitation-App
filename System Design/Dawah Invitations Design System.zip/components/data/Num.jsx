import React from 'react';
/** Localised number. lang="ar" → Arabic-Indic digits (١٢٣); "en" → Western. Phone numbers must NOT use this — see Phone. */
export function formatNum(n, lang = 'ar', opts) { return new Intl.NumberFormat(lang === 'ar' ? 'ar-SA-u-nu-arab' : 'en-US', opts).format(Number(n) || 0); }
export function formatPercent(n, lang = 'ar') { return formatNum(n, lang) + (lang === 'ar' ? '٪' : '%'); }
export function Num({ value, lang = 'ar', percent = false, style, ...rest }) {
  return <span className="num" style={style} {...rest}>{percent ? formatPercent(value, lang) : formatNum(value, lang)}</span>;
}
