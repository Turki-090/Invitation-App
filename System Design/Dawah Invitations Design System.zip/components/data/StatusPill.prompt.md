The one way to show a status: coloured icon + text pill, with separate vocabularies for RSVP, delivery, check-in and event.

```jsx
<StatusPill status="partial" detail="٣ من ٤" />
<StatusPill kind="delivery" status="read" />
<StatusPill kind="event" status="rsvp-open" lang="en" />
```

- RSVP: not-sent · pending · accepted · partial · declined.
- Delivery: draft · ready · queued · sent · delivered · read · responded · failed · cancelled.
- Check-in: not-arrived · partial · checked-in · already-scanned.
- Never show delivery and RSVP in one pill.
