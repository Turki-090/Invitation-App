import React from 'react';
import { Icon } from '../core/Icon.jsx';
/** Vertical event list for delivery timelines and activity history. items: [{label, time, tone, icon, meta}]. tone = status token; last item may be `pending` (hollow dot). */
export function Timeline({ items = [], dense = false, style }) {
  return (
    <ol style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', ...style }}>
      {items.map((it, i) => {
        const last = i === items.length - 1;
        const c = it.tone ? `var(--${it.tone})` : 'var(--line-strong)';
        return (
          <li key={i} style={{ display: 'flex', gap: 12, position: 'relative', paddingBottom: last ? 0 : dense ? 12 : 18 }}>
            <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 'none', width: 20 }}>
              <span aria-hidden style={{ width: it.icon ? 20 : 10, height: it.icon ? 20 : 10, marginTop: it.icon ? 0 : 5, borderRadius: '50%', background: it.hollow ? 'var(--surface-card)' : c, border: it.hollow ? `2px solid ${c}` : 'none', color: '#fff', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{it.icon ? <Icon name={it.icon} size={12} strokeWidth={2.5} /> : null}</span>
              {!last ? <span aria-hidden style={{ flex: 1, width: 2, background: 'var(--border-default)', marginTop: 4 }} /> : null}
            </span>
            <div style={{ flex: 1, minWidth: 0, display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'baseline' }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 'var(--text-md)', fontWeight: it.strong ? 600 : 500, lineHeight: 1.4, color: it.hollow ? 'var(--text-muted)' : 'var(--text-body)' }}>{it.label}</div>
                {it.meta ? <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', marginTop: 2 }}>{it.meta}</div> : null}
              </div>
              {it.time ? <span className="num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{it.time}</span> : null}
            </div>
          </li>);
      })}
    </ol>
  );
}
