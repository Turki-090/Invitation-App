Displays a WhatsApp number LTR with Western digits; masks middle digits for restricted roles.

```jsx
<Phone value="+966501234567" />
<Phone value="+966501234567" masked />
```

- Respects the "view full phone numbers" permission via `masked`.
