import * as React from 'react';
/** Segmented RSVP progress with legend. */
export interface ProgressBarProps {
  segments: { label: string;
  value: number;
  tone?: string }[];
  total?: number;
  lang?: 'ar'|'en';
  height?: number;
  legend?: boolean;
  style?: React.CSSProperties;
}
export function ProgressBar(props: ProgressBarProps): JSX.Element;
