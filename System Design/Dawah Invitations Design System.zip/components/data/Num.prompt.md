Localised numeral (١٢٣ in Arabic, 123 in English); also exports formatNum/formatPercent helpers.

```jsx
<Num value={497} />  <Num value={62} percent lang="en" />
```

- Never use for phone numbers — those use `Phone`.
