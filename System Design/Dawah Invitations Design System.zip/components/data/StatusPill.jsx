import React from 'react';
import { Icon } from '../core/Icon.jsx';
/** Every status = tone + icon + text. Three separate vocabularies; never mix RSVP and delivery in one pill. */
export const STATUS = {
  rsvp: {
    'not-sent': { tone: 'notsent', icon: 'circle-dashed', ar: 'لم تُرسل', en: 'Not sent' },
    pending: { tone: 'pending', icon: 'clock', ar: 'بانتظار الرد', en: 'Pending' },
    accepted: { tone: 'accepted', icon: 'circle-check', ar: 'تم القبول', en: 'Accepted' },
    partial: { tone: 'partial', icon: 'circle-dot', ar: 'قبول جزئي', en: 'Partially accepted' },
    declined: { tone: 'declined', icon: 'circle-x', ar: 'اعتذار', en: 'Declined' },
  },
  delivery: {
    draft: { tone: 'notsent', icon: 'file-text', ar: 'مسودة', en: 'Draft' },
    ready: { tone: 'notsent', icon: 'circle-dashed', ar: 'جاهزة', en: 'Ready' },
    queued: { tone: 'pending', icon: 'clock', ar: 'في الانتظار', en: 'Queued' },
    sent: { tone: 'notsent', icon: 'check', ar: 'أُرسلت', en: 'Sent' },
    delivered: { tone: 'partial', icon: 'check-check', ar: 'تم التوصيل', en: 'Delivered' },
    read: { tone: 'checkedin', icon: 'eye', ar: 'تمت القراءة', en: 'Read' },
    responded: { tone: 'accepted', icon: 'reply', ar: 'تم الرد', en: 'Responded' },
    failed: { tone: 'failed', icon: 'circle-alert', ar: 'فشل الإرسال', en: 'Failed' },
    cancelled: { tone: 'notsent', icon: 'ban', ar: 'أُلغيت', en: 'Cancelled' },
  },
  checkin: {
    'not-arrived': { tone: 'notsent', icon: 'circle-dashed', ar: 'لم يصل', en: 'Not arrived' },
    partial: { tone: 'partial', icon: 'users', ar: 'وصول جزئي', en: 'Partially checked in' },
    'checked-in': { tone: 'checkedin', icon: 'badge-check', ar: 'تم الدخول', en: 'Checked in' },
    'already-scanned': { tone: 'pending', icon: 'triangle-alert', ar: 'مُسح مسبقًا', en: 'Already scanned' },
  },
  event: {
    upcoming: { tone: 'notsent', icon: 'calendar', ar: 'قادمة', en: 'Upcoming' },
    sending: { tone: 'pending', icon: 'send', ar: 'جارٍ الإرسال', en: 'Sending' },
    'rsvp-open': { tone: 'accepted', icon: 'mail-open', ar: 'الردود مفتوحة', en: 'RSVP open' },
    'rsvp-closed': { tone: 'partial', icon: 'lock', ar: 'الردود مغلقة', en: 'RSVP closed' },
    today: { tone: 'checkedin', icon: 'sparkles', ar: 'اليوم', en: 'Today' },
    completed: { tone: 'notsent', icon: 'check', ar: 'منتهية', en: 'Completed' },
    archived: { tone: 'notsent', icon: 'archive', ar: 'مؤرشفة', en: 'Archived' },
  },
};
export function StatusPill({ kind = 'rsvp', status, lang = 'ar', label, detail, size = 'md', variant = 'soft', style }) {
  const d = (STATUS[kind] || {})[status] || { tone: 'notsent', icon: 'circle', ar: status, en: status };
  const t = d.tone;
  const soft = variant === 'soft';
  const h = size === 'sm' ? 22 : 26;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, height: h, padding: `0 ${size === 'sm' ? 7 : 9}px`, borderRadius: 'var(--radius-pill)', whiteSpace: 'nowrap',
      background: soft ? `var(--${t}-bg)` : 'transparent', color: `var(--${t}-fg)`, fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)', fontWeight: 500, lineHeight: 1, ...style }}>
      <Icon name={d.icon} size={size === 'sm' ? 13 : 14} color={`var(--${t})`} strokeWidth={2} />
      <span>{label || d[lang] || d.ar}</span>
      {detail ? <span className="num" style={{ opacity: .8, fontWeight: 400 }}>· {detail}</span> : null}
    </span>
  );
}
