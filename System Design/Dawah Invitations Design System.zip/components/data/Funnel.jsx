import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { formatNum, formatPercent } from './Num.jsx';
/** WhatsApp delivery funnel: Sent → Delivered → Read → Responded. steps: [{label, value}]. Bars are relative to the first step; chevrons follow reading direction. */
export function Funnel({ steps = [], lang = 'ar', style }) {
  const base = steps[0]?.value || 1;
  return (
    <div style={{ display: 'flex', alignItems: 'stretch', gap: 8, ...style }}>
      {steps.map((s, i) => (
        <React.Fragment key={i}>
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', fontWeight: 500 }}>{s.label}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <span className="num" style={{ fontSize: 'var(--text-2xl)', fontWeight: 600, lineHeight: 1 }}>{formatNum(s.value, lang)}</span>
              {i > 0 ? <span className="num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{formatPercent(Math.round(s.value / base * 100), lang)}</span> : null}
            </div>
            <div style={{ height: 6, borderRadius: 999, background: 'var(--surface-sunken)', overflow: 'hidden' }}><span style={{ display: 'block', height: '100%', width: `${Math.min(100, s.value / base * 100)}%`, background: i === steps.length - 1 ? 'var(--accepted)' : 'var(--ink)', opacity: .35 + (.65 * (i + 1) / steps.length) }} /></div>
          </div>
          {i < steps.length - 1 ? <span style={{ alignSelf: 'center', color: 'var(--text-disabled)', display: 'inline-flex', marginTop: 8 }}><Icon name="chevron-right" size={16} flipRtl /></span> : null}
        </React.Fragment>))}
    </div>
  );
}
