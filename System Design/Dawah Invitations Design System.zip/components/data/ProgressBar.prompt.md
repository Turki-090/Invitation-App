Stacked RSVP progress (accepted / partial / declined / pending / not sent) with a labelled legend.

```jsx
<ProgressBar segments={[{label:'تم القبول',value:280,tone:'accepted'},{label:'اعتذار',value:54,tone:'declined'},{label:'بانتظار الرد',value:89,tone:'pending'},{label:'لم تُرسل',value:27,tone:'notsent'}]} />
```

- Legend shows label + % + count, so colour is never the only cue.
