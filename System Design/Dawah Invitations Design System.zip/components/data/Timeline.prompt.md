Vertical timeline for message delivery and guest activity history (manual changes named).

```jsx
<Timeline items={[{label:'أُرسلت الدعوة',time:'٧:٣٢ م',tone:'notsent'},{label:'تمت القراءة',time:'٧:٤١ م',tone:'checkedin'},{label:'قبول مع مرافقَين',time:'٧:٤٣ م',tone:'accepted',strong:true}]} />
```

- `hollow` marks a future/pending step.
- Manual host changes: meta = "تغيير يدوي بواسطة خالد العمري".
