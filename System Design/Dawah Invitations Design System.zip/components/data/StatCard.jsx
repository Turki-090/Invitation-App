import React, { useState } from 'react';
import { Icon } from '../core/Icon.jsx';
import { formatNum } from './Num.jsx';
/** Overview metric. `context` disambiguates the unit ("مجموعة دعوات", "شخص متوقع") — required by the counting rule. tone colours a small dot, never the number. */
export function StatCard({ label, value, context, footnote, tone, icon, lang = 'ar', onClick, size = 'md', style }) {
  const [hov, setHov] = useState(false);
  const big = size === 'lg';
  return (
    <div role={onClick ? 'button' : undefined} tabIndex={onClick ? 0 : undefined} onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: big ? 24 : 18, background: 'var(--surface-card)', border: `1px solid ${hov && onClick ? 'var(--border-strong)' : 'var(--border-default)'}`, borderRadius: 'var(--radius-card)', boxShadow: 'var(--shadow-card)', cursor: onClick ? 'pointer' : 'default', transition: 'var(--transition-control)', minWidth: 0, ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-muted)', fontSize: 'var(--text-sm)', fontWeight: 500 }}>
        {tone ? <span aria-hidden style={{ width: 8, height: 8, borderRadius: '50%', background: `var(--${tone})`, flex: 'none' }} /> : icon ? <Icon name={icon} size={16} /> : null}
        <span style={{ flex: 1 }}>{label}</span>
        {onClick ? <Icon name="arrow-left" size={14} flipRtl style={{ opacity: hov ? 1 : 0, transition: 'opacity var(--dur-fast)' }} /> : null}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, flexWrap: 'wrap' }}>
        <span className="num" style={{ fontSize: big ? 'var(--text-4xl)' : 'var(--text-3xl)', fontWeight: 600, lineHeight: 1.1, letterSpacing: 'var(--tracking-tight)' }}>{typeof value === 'number' ? formatNum(value, lang) : value}</span>
        {context ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{context}</span> : null}
      </div>
      {footnote ? <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', marginTop: 2 }}>{footnote}</div> : null}
    </div>
  );
}
