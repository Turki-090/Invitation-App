Dashboard metric card whose `context` always names the unit (groups vs people).

```jsx
<StatCard label="المتوقع حضورهم" value={497} context="شخص" tone="accepted" onClick={…} />
```

- `tone` colours a small dot only. Clickable cards show an arrow on hover (actionable-dashboard rule).
