import * as React from 'react';
/** Status pill = tone + icon + text. kind selects the vocabulary.
 * @startingPoint section="Data" subtitle="RSVP, delivery, check-in and event statuses" viewport="700x400" */
export interface StatusPillProps {
  kind?: 'rsvp'|'delivery'|'checkin'|'event';
  status: string;
  lang?: 'ar'|'en';
  label?: string;
  /** e.g. "٣ من ٤" */ detail?: React.ReactNode;
  size?: 'sm'|'md';
  variant?: 'soft'|'plain';
  style?: React.CSSProperties;
}
export function StatusPill(props: StatusPillProps): JSX.Element;
