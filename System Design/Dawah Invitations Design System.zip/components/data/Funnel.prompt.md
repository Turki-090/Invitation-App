WhatsApp delivery funnel for the overview and sending centre.

```jsx
<Funnel steps={[{label:'أُرسلت',value:423},{label:'تم التوصيل',value:410},{label:'تمت القراءة',value:388},{label:'تم الرد',value:334}]} />
```

- Percentages are relative to the first step.
