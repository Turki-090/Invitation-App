import * as React from 'react';
/** Guest list data table with selection. */
export interface TableProps {
  columns: { key: string;
  header: React.ReactNode;
  width?: number|string;
  align?: 'start'|'end'|'center';
  wrap?: boolean;
  render?: (row: any) => React.ReactNode }[];
  rows: any[];
  rowKey?: string;
  selectable?: boolean;
  selected?: (string|number)[];
  onSelect?: (ids: (string|number)[]) => void;
  onRowClick?: (row: any) => void;
  dense?: boolean;
  emptyState?: React.ReactNode;
  selectAllLabel?: string;
  style?: React.CSSProperties;
}
export function Table(props: TableProps): JSX.Element;
