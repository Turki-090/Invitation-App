# UI kit — WhatsApp channel

The primary guest interaction surface. Three chats (single · named family · person + companions) show the invitation message and the quick-reply buttons each type receives; tapping a reply appends the guest's message and the immediate acknowledgement (confirmed with attendee count, or apology recorded) plus follow-up actions (location, change response, entry pass). "Select attendees" demonstrates the fallback to a minimal no-login page when WhatsApp buttons can't express a multi-person choice.

WhatsApp colours (`--wa-*`) are used only here and in the Sending centre preview — never in dashboard UI. Message copy lives in `chat.screen.jsx → M` in Arabic and English.
