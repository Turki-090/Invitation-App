# UI kit — Host dashboard

Desktop-first responsive host application, Arabic RTL as the source layout with an English LTR toggle in the top bar.

Open `index.html`. Screens (sidebar): Overview (with **event-day mode** switch), Guests (status tabs, search, bulk-action bar, **Add guest** drawer with the three invitation types + duplicate-number error, **Guest details** drawer with delivery timeline & activity history, delete-responded confirmation), Invitations/Sending centre (template, audience, WhatsApp preview per type, send confirmation → live progress → failed-message actions), Reminders (segments, auto-reminder rules, history, "reminded yesterday" guard), Check-in (scan/search → party-size stepper → success → already-scanned warning), Team (roles, per-permission switches, pending invite), Reports (groups vs people, exports), Event settings (RSVP rules, WhatsApp connection, danger zone with typed confirmation).

Files: `data.jsx` (bilingual strings + sample guests), `shell.screen.jsx` (Sidebar, Topbar, BottomNav, PageHeader, Drawer, Section), one file per screen, `app.screen.jsx`.

Responsive: <1100px sidebar collapses to icons; <800px sidebar hides, bottom nav appears, grids stack. Table would switch to cards in production — here it scrolls horizontally.

Everything visual comes from `components/` via the bundle; no styling is redefined here except layout grid classes.
