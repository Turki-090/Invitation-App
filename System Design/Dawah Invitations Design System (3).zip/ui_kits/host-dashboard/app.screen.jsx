function App() {
  const [lang, setLang] = React.useState('ar'); const [page, setPage] = React.useState('overview'); const [eventDay, setEventDay] = React.useState(false);
  const t = T[lang];
  React.useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; }, [lang]);
  const P = { overview: Overview, guests: Guests, sending: Sending, reminders: Reminders, checkin: Checkin, team: Team, reports: Reports, settings: Settings }[page];
  return <div className="app" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
    <Sidebar t={t} page={page} setPage={setPage} lang={lang} />
    <div className="main">
      <Topbar t={t} title={t.nav[page]} lang={lang} setLang={setLang} />
      <div className="content" key={page + lang}><P t={t} lang={lang} setPage={setPage} eventDay={eventDay} setEventDay={setEventDay} /></div>
      <BottomNav t={t} page={page} setPage={setPage} />
    </div>
  </div>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
