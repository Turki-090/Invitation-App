const { StatCard, ProgressBar, Funnel, Timeline, Banner, Card, Button, Avatar, Switch, Tag, StatusPill } = DS;
function Overview({ t, lang, setPage, eventDay, setEventDay }) {
  const S = STATS;
  const activity = lang === 'ar'
    ? [{ label: 'محمد العتيبي قبل الدعوة مع مرافقَين', time: '٧:٤٣ م', tone: 'accepted', icon: 'check', meta: '٣ أشخاص متوقعون' }, { label: 'عائلة الدوسري: قبول جزئي', time: '٦:١٠ م', tone: 'partial', icon: 'users', meta: '٣ من ٤ سيحضرون' }, { label: 'تغيير الرد يدويًا لريم المطيري', time: '٥:٢٢ م', tone: 'notsent', icon: 'pencil', meta: 'بواسطة خالد العمري' }, { label: 'اكتمل التذكير التلقائي الأول', time: 'أمس', tone: 'checkedin', icon: 'bell', meta: 'أُرسل إلى ١٠٤ مجموعات' }]
    : [{ label: 'Mohammed Al-Otaibi accepted with 2 companions', time: '7:43 PM', tone: 'accepted', icon: 'check', meta: '3 people expected' }, { label: 'Al-Dosari family: partially accepted', time: '6:10 PM', tone: 'partial', icon: 'users', meta: '3 of 4 attending' }, { label: 'RSVP changed manually for Reem Al-Mutairi', time: '5:22 PM', tone: 'notsent', icon: 'pencil', meta: 'by Khalid Al-Omari' }, { label: 'First automatic reminder completed', time: 'Yesterday', tone: 'checkedin', icon: 'bell', meta: 'Sent to 104 groups' }];
  const team = lang === 'ar' ? [['خالد العمري', 'مالك'], ['نورة الشمري', 'مضيف مشارك'], ['فهد الحارثي', 'تسجيل الدخول']] : [['Khalid Al-Omari', 'Owner'], ['Noura Al-Shammari', 'Co-host'], ['Fahad Al-Harthi', 'Check-in']];
  return <>
    <PageHeader title={t.event} meta={t.eventMeta}>
      <Switch checked={eventDay} onChange={setEventDay} label={t.eventDay} />
      {eventDay ? <Button variant="accent" icon="qr-code" onClick={() => setPage('checkin')}>{t.openCheckin}</Button> : <Button icon="send" onClick={() => setPage('sending')}>{t.sendInv}</Button>}
    </PageHeader>
    {eventDay ? <>
      <Card tone="dark" style={{ marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 24 }}>
          {[[t.expected, S.expected, 'peopleUnit'], [t.checkedin, S.checkedin, 'peopleUnit'], [t.remaining, S.expected - S.checkedin, 'peopleUnit'], [t.checkinPct, Math.round(S.checkedin / S.expected * 100) + (lang === 'ar' ? '٪' : '%'), null]].map(([l, v, u], i) => (
            <div key={i}><div style={{ fontSize: 13, opacity: .7, fontWeight: 500 }}>{l}</div><div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}><span className="num" style={{ fontSize: 48, fontWeight: 600, lineHeight: 1.1, letterSpacing: '-.01em' }}>{typeof v === 'number' ? fmt(v, lang) : v}</span>{u ? <span style={{ fontSize: 13, opacity: .7 }}>{t[u]}</span> : null}</div></div>))}
        </div>
        <div style={{ height: 8, borderRadius: 999, background: 'rgba(255,255,255,.12)', marginTop: 20 }}><span style={{ display: 'block', height: '100%', width: `${S.checkedin / S.expected * 100}%`, borderRadius: 999, background: 'var(--bronze-light)' }} /></div>
      </Card>
      <div className="grid2">
        <Card title={t.arrivals}><Timeline dense items={(lang === 'ar' ? [['عائلة العنزي — ٣ أشخاص', '٨:٤١ م', 'badge-check', 'checkedin'], ['سارة القحطاني', '٨:٣٩ م', 'badge-check', 'checkedin'], ['محاولة مسح مكرر — محمد العتيبي', '٨:٣٥ م', 'triangle-alert', 'pending'], ['عائلة الدوسري — ٢ من ٣', '٨:٣٠ م', 'users', 'partial']] : [['Al-Anazi family — 3 people', '8:41 PM', 'badge-check', 'checkedin'], ['Sarah Al-Qahtani', '8:39 PM', 'badge-check', 'checkedin'], ['Duplicate QR attempt — Mohammed Al-Otaibi', '8:35 PM', 'triangle-alert', 'pending'], ['Al-Dosari family — 2 of 3', '8:30 PM', 'users', 'partial']]).map(([label, time, icon, tone]) => ({ label, time, icon, tone }))} /></Card>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Banner kind="warning" title={lang === 'ar' ? 'محاولة مسح مكرر لدعوة واحدة' : '1 duplicate QR attempt'} actionLabel={lang === 'ar' ? 'عرض' : 'View'} compact />
          <Banner kind="info" icon="search" title={lang === 'ar' ? 'ضيفان لم يُعثر عليهما بالمسح' : '2 guests not found by scan'} actionLabel={lang === 'ar' ? 'بحث يدوي' : 'Manual search'} compact />
        </div>
      </div>
    </> : <>
      <div className="grid4" style={{ marginBottom: 14 }}>
        <Banner kind="danger" title={t.att1} description={t.att1d} actionLabel={t.att1a} onAction={() => setPage('sending')} />
        <Banner kind="warning" title={t.att2} actionLabel={t.att2a} onAction={() => setPage('reminders')} compact />
        <Banner kind="info" icon="calendar" title={t.att3} actionLabel={t.att3a} onAction={() => setPage('guests')} compact />
        <Banner kind="neutral" icon="send" title={t.att4} actionLabel={t.att4a} onAction={() => setPage('sending')} compact />
      </div>
      <div className="grid4" style={{ marginBottom: 14 }}>
        <StatCard label={t.groups} value={S.groups} context={t.groupsUnit} icon="mail" lang={lang} onClick={() => setPage('guests')} />
        <StatCard label={t.named} value={S.named} context={t.peopleUnit} icon="users" lang={lang} />
        <StatCard label={t.pending} value={S.pending + S.notsent} context={t.groupsUnit} tone="pending" lang={lang} footnote={`${fmt(S.notsent, lang)} ${t.notsent.toLowerCase()}`} onClick={() => setPage('reminders')} />
        <StatCard label={t.expected} value={S.expected} context={t.peopleUnit} tone="accepted" lang={lang} footnote={lang === 'ar' ? '+١٨ هذا الأسبوع' : '+18 this week'} />
      </div>
      <div className="grid2" style={{ marginBottom: 14 }}>
        <Card title={t.rsvpProgress} subtitle={`${fmt(S.groups, lang)} ${t.groupsUnit}`}>
          <ProgressBar lang={lang} segments={[{ label: t.accepted, value: S.accepted, tone: 'accepted' }, { label: t.partial, value: S.partial, tone: 'partial' }, { label: t.declined, value: S.declined, tone: 'declined' }, { label: t.pending, value: S.pending, tone: 'pending' }, { label: t.notsent, value: S.notsent, tone: 'notsent' }]} />
        </Card>
        <Card title={t.funnel}><Funnel lang={lang} steps={[t.sent, t.delivered, t.read, t.responded].map((label, i) => ({ label, value: S.funnel[i] }))} /></Card>
      </div>
      <div className="grid2">
        <Card title={t.activity} actions={<Button variant="ghost" size="sm" iconEnd="arrow-left" onClick={() => setPage('guests')}>{t.viewAll}</Button>}><Timeline items={activity} /></Card>
        <Card title={t.team} actions={<Button variant="ghost" size="sm" iconEnd="arrow-left" onClick={() => setPage('team')}>{t.viewAll}</Button>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>{team.map(([n, r]) => <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10 }}><Avatar name={n} size="sm" /><span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{n}</span><Tag size="sm">{r}</Tag></div>)}</div>
        </Card>
      </div>
    </>}
  </>;
}
Object.assign(window, { Overview });
