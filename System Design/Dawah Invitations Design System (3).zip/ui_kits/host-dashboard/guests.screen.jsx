const { Tabs, Table, Button, IconButton, Input, Avatar, Phone, StatusPill, Num, Tag, Field, PhoneInput, Select, ChoiceCard, Stepper, Checkbox, EmptyState, Timeline, Card, Dialog, Toast } = DS;
function Guests({ t, lang }) {
  const [tab, setTab] = React.useState('all'); const [q, setQ] = React.useState(''); const [sel, setSel] = React.useState([]);
  const [adding, setAdding] = React.useState(false); const [detail, setDetail] = React.useState(null); const [confirmDel, setConfirmDel] = React.useState(false); const [toast, setToast] = React.useState(null);
  const counts = { all: 450, accepted: 280, partial: 31, declined: 54, pending: 58, 'not-sent': 27, failed: 3 };
  const rows = GUESTS.filter(g => tab === 'all' || (tab === 'failed' ? g.del === 'failed' : g.rsvp === tab)).filter(g => !q || g.name[lang].includes(q) || g.phone.includes(q.replace(/\s/g, '')));
  const cols = [
    { key: 'name', header: t.cols.contact, render: g => <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}><Avatar name={g.name[lang]} size="sm" /><div><div style={{ fontWeight: 500 }}>{g.name[lang]}</div><Phone value={g.phone} /></div></div> },
    { key: 'type', header: t.cols.type, render: g => <span style={{ display: 'inline-flex', gap: 6, alignItems: 'center', color: 'var(--text-secondary)' }}><DS.Icon name={g.type === 'single' ? 'user' : g.type === 'family' ? 'users' : 'user-plus'} size={15} />{t.types[g.type]}</span> },
    { key: 'size', header: t.cols.size, align: 'end', render: g => <span className="num">{g.type === 'companions' ? `1+${g.maxComp}` : fmt(g.size, lang)}</span> },
    { key: 'exp', header: t.cols.exp, align: 'end', render: g => <span className="num" style={{ fontWeight: 600, color: g.exp ? 'inherit' : 'var(--text-muted)' }}>{fmt(g.exp, lang)}</span> },
    { key: 'del', header: t.cols.delivery, render: g => <StatusPill kind="delivery" status={g.del} lang={lang} size="sm" /> },
    { key: 'rsvp', header: t.cols.rsvp, render: g => <StatusPill status={g.rsvp} lang={lang} size="sm" detail={g.detail && g.detail[lang]} /> },
    { key: 'last', header: t.cols.last, render: g => <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{g.last[lang]}</span> },
    { key: 'a', header: '', align: 'end', render: g => <IconButton name="ellipsis" label={t.more} size="sm" onClick={e => { e.stopPropagation(); setDetail(g); }} /> },
  ];
  return <>
    <PageHeader title={t.nav.guests} meta={`${fmt(450, lang)} ${t.groupsUnit} · ${fmt(620, lang)} ${t.named.toLowerCase()} · ${fmt(497, lang)} ${t.expected.toLowerCase()}`}>
      <Button variant="secondary" icon="upload">{t.importExcel}</Button><Button icon="plus" onClick={() => setAdding(true)}>{t.addGuest}</Button>
    </PageHeader>
    <Tabs value={tab} onChange={setTab} items={Object.keys(counts).map(id => ({ id, label: t.tabs[id], count: fmt(counts[id], lang) }))} style={{ marginBottom: 14 }} />
    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 14, flexWrap: 'wrap' }}>
      <Input icon="search" placeholder={t.search} size="sm" value={q} onChange={e => setQ(e.target.value)} style={{ width: 320, maxWidth: '100%' }} />
      <Button variant="secondary" size="sm" icon="filter">{t.filter}</Button><Button variant="secondary" size="sm" icon="download">{t.export}</Button>
      {sel.length > 0 ? <div style={{ marginInlineStart: 'auto', display: 'flex', alignItems: 'center', gap: 6, padding: '4px 6px 4px 12px', background: 'var(--ink)', color: 'var(--text-on-dark)', borderRadius: 'var(--radius-md)' }}>
        <span className="num" style={{ fontSize: 13, fontWeight: 600, marginInlineEnd: 6 }}>{fmt(sel.length, lang)} {t.selected}</span>
        {[['send', t.sendInv], ['bell', t.sendRem], ['check-circle', t.markRsvp], ['download', t.export]].map(([ic, l]) => <Button key={l} size="sm" variant="ghost" icon={ic} style={{ color: 'var(--text-on-dark)' }} onClick={() => { setToast(l); setSel([]); }}>{l}</Button>)}
        <Button size="sm" variant="ghost" icon="trash-2" style={{ color: '#F1B3A5' }} onClick={() => setConfirmDel(true)}>{t.deleteG}</Button>
      </div> : null}
    </div>
    <Table selectable selected={sel} onSelect={setSel} columns={cols} rows={rows} onRowClick={setDetail} emptyState={<EmptyState icon="search" title={t.noResults} description={t.noResultsD} action={<Button variant="secondary" size="sm" onClick={() => { setQ(''); setTab('all'); }}>{lang === 'ar' ? 'إزالة التصفية' : 'Clear filters'}</Button>} />} />
    {adding ? <AddGuest t={t} lang={lang} onClose={() => setAdding(false)} onSaved={m => { setAdding(false); setToast(m); }} /> : null}
    {detail ? <GuestDetail g={detail} t={t} lang={lang} onClose={() => setDetail(null)} /> : null}
    {confirmDel ? <Dialog danger title={lang === 'ar' ? 'حذف ضيوف سبق أن ردّوا؟' : 'Delete guests who already responded?'} description={lang === 'ar' ? `من بين ${fmt(sel.length, lang)} ضيوف محددين، ردّ بعضهم على الدعوة. سيُحذف ردّهم من العدد المتوقع.` : `Some of the ${sel.length} selected guests have already responded. Their RSVP will be removed from the expected count.`} onClose={() => setConfirmDel(false)} actions={<><Button variant="secondary" onClick={() => setConfirmDel(false)}>{t.add.cancel}</Button><Button variant="danger" onClick={() => { setConfirmDel(false); setSel([]); setToast(t.deleteG); }}>{t.deleteG}</Button></>} /> : null}
    {toast ? <div style={{ position: 'absolute', bottom: 24, insetInlineStart: 24, zIndex: 30 }}><Toast title={lang === 'ar' ? `تم: ${toast}` : `Done: ${toast}`} onDismiss={() => setToast(null)} /></div> : null}
  </>;
}
function AddGuest({ t, lang, onClose, onSaved }) {
  const a = t.add; const [type, setType] = React.useState('family'); const [phone, setPhone] = React.useState('55 555 5123'); const [members, setMembers] = React.useState(['', '']); const [n, setN] = React.useState(2);
  const dup = phone.replace(/\s/g, '') === '555555123';
  return <Drawer title={a.title} onClose={onClose} footer={<><Button variant="ghost" onClick={onClose}>{a.cancel}</Button><Button variant="secondary" onClick={() => onSaved(a.draft)}>{a.draft}</Button><Button icon="send" disabled={dup} onClick={() => onSaved(a.saveSend)}>{a.saveSend}</Button></>}>
    <Section title={a.type}>
      <ChoiceCard icon="user" title={a.single} description={a.singleD} selected={type === 'single'} onClick={() => setType('single')} />
      <ChoiceCard icon="users" title={a.family} description={a.familyD} selected={type === 'family'} onClick={() => setType('family')} />
      <ChoiceCard icon="user-plus" title={a.comp} description={a.compD} selected={type === 'companions'} onClick={() => setType('companions')} />
    </Section>
    <Field label={type === 'family' ? a.groupName : a.name} required><Input placeholder={type === 'family' ? (lang === 'ar' ? 'عائلة الدوسري' : 'Al-Dosari family') : (lang === 'ar' ? 'سارة القحطاني' : 'Sarah Al-Qahtani')} /></Field>
    <Field label={a.phone} required error={dup ? a.dup : undefined}><PhoneInput value={phone} onChange={e => setPhone(e.target.value)} invalid={dup} /></Field>
    {type === 'family' ? <Section title={a.members}>
      {members.map((m, i) => <div key={i} style={{ display: 'flex', gap: 8 }}><Input value={m} onChange={e => setMembers(members.map((x, j) => j === i ? e.target.value : x))} placeholder={lang === 'ar' ? `الفرد ${fmt(i + 1, lang)}` : `Member ${i + 1}`} style={{ flex: 1 }} /><IconButton name="grip-vertical" label="reorder" /><IconButton name="x" label="remove" onClick={() => setMembers(members.filter((_, j) => j !== i))} /></div>)}
      <Button variant="secondary" size="sm" icon="plus" onClick={() => setMembers([...members, ''])} style={{ alignSelf: 'flex-start' }}>{a.addMember}</Button>
    </Section> : null}
    {type === 'companions' ? <Field label={a.comps} hint={lang === 'ar' ? 'لا تحتاج معرفة أسماء المرافقين' : 'You don’t need companion names'}><Stepper value={n} max={10} onChange={setN} format={v => fmt(v, lang)} /></Field> : null}
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
      <Field label={a.tag} optionalLabel={a.optional}><Select placeholder={a.tag} options={[{ value: 'b', label: lang === 'ar' ? 'أهل العروس' : 'Bride’s family' }, { value: 'g', label: lang === 'ar' ? 'أهل العريس' : 'Groom’s family' }, { value: 'f', label: lang === 'ar' ? 'الأصدقاء' : 'Friends' }]} /></Field>
      <Field label={a.note} optionalLabel={a.optional}><Input placeholder="…" /></Field>
    </div>
  </Drawer>;
}
function GuestDetail({ g, t, lang, onClose }) {
  const d = t.det; const ar = lang === 'ar';
  const tl = g.del === 'failed' ? [{ label: ar ? 'في الانتظار' : 'Queued', time: ar ? '٤:٠٠ م' : '4:00 PM', tone: 'notsent', icon: 'clock' }, { label: ar ? 'فشل الإرسال — رقم غير متاح على واتساب' : 'Failed — number not on WhatsApp', time: ar ? '٤:٠١ م' : '4:01 PM', tone: 'failed', icon: 'circle-alert', strong: true }]
    : [{ label: ar ? 'أُرسلت الدعوة' : 'Invitation sent', time: ar ? '٧:٣٢ م' : '7:32 PM', tone: 'notsent', icon: 'check' }, { label: ar ? 'تم التوصيل' : 'Delivered', time: ar ? '٧:٣٣ م' : '7:33 PM', tone: 'partial', icon: 'check-check' }, ...(['read', 'responded'].includes(g.del) ? [{ label: ar ? 'تمت القراءة' : 'Read', time: ar ? '٧:٤١ م' : '7:41 PM', tone: 'checkedin', icon: 'eye' }] : [{ label: ar ? 'القراءة' : 'Read', hollow: true, tone: 'notsent' }]), ...(g.del === 'responded' || g.rsvp === 'accepted' || g.rsvp === 'declined' ? [{ label: g.rsvp === 'declined' ? (ar ? 'اعتذار' : 'Declined') : ar ? `قبول${g.detail ? ' · ' + g.detail.ar : ''}` : `Accepted${g.detail ? ' · ' + g.detail.en : ''}`, time: ar ? '٧:٤٣ م' : '7:43 PM', tone: g.rsvp === 'declined' ? 'declined' : 'accepted', icon: g.rsvp === 'declined' ? 'x' : 'check', strong: true }] : [{ label: ar ? 'الرد' : 'Response', hollow: true, tone: 'pending' }])];
  return <Drawer title={g.name[lang]} onClose={onClose} footer={<><Button variant="ghost" size="sm" icon="trash-2" style={{ color: 'var(--danger-fg)' }}>{d.del}</Button><Button variant="ghost" size="sm" icon="ban">{d.cancelInv}</Button><span style={{ flex: 1 }} /><Button variant="secondary" size="sm" icon="pencil">{d.edit}</Button><Button size="sm" icon={g.del === 'failed' ? 'refresh-cw' : 'bell'}>{g.del === 'failed' ? d.resend : d.remind}</Button></>}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><Avatar name={g.name[lang]} size="lg" /><div style={{ flex: 1 }}><div style={{ fontSize: 17, fontWeight: 600 }}>{g.name[lang]}</div><Phone value={g.phone} style={{ fontSize: 14 }} /></div><Button variant="whatsapp" size="sm" icon="message-circle">{d.openWa}</Button></div>
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><StatusPill status={g.rsvp} lang={lang} detail={g.detail && g.detail[lang]} /><StatusPill kind="delivery" status={g.del} lang={lang} /><Tag>{g.tag[lang]}</Tag></div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
      <Card tone="sunken" padding="14px"><div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>{d.invDef}</div><div style={{ fontSize: 15, fontWeight: 600, marginTop: 4 }}>{t.types[g.type]}</div><div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{g.type === 'companions' ? `${d.maxComp}: ${fmt(g.maxComp, lang)}` : g.type === 'family' ? `${fmt(g.size, lang)} ${d.members.toLowerCase()}` : ar ? 'شخص واحد' : '1 person'}</div></Card>
      <Card tone="sunken" padding="14px"><div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>{d.partySize}</div><div className="num" style={{ fontSize: 26, fontWeight: 600, marginTop: 2, lineHeight: 1.2 }}>{fmt(g.exp, lang)} <span style={{ fontSize: 13, fontWeight: 400, color: 'var(--text-secondary)' }}>{t.peopleUnit}</span></div><div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{d.lastResp}: {g.last[lang]}</div></Card>
    </div>
    {g.type === 'family' ? <Section title={d.members}><div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{g.members.map((m, i) => <Checkbox key={m} checked={!!(g.attending && g.attending[i])} label={ar ? m : g.membersEn[i]} description={g.attending ? (g.attending[i] ? (ar ? 'سيحضر' : 'Attending') : (ar ? 'لن يحضر' : 'Not attending')) : (ar ? 'لم يرد' : 'No response')} />)}</div></Section> : null}
    <Section title={d.delivery}><Timeline items={tl} /></Section>
    <Section title={d.history}><Timeline dense items={[{ label: ar ? 'أُضيف الضيف' : 'Guest added', time: ar ? '٣ مايو' : '3 May', tone: 'notsent', meta: ar ? 'بواسطة نورة الشمري (استيراد Excel)' : 'by Noura Al-Shammari (Excel import)' }, ...(g.rsvp === 'declined' ? [{ label: ar ? 'تغيير الرد يدويًا إلى اعتذار' : 'RSVP manually changed to Declined', time: ar ? '٥:٢٢ م' : '5:22 PM', tone: 'declined', meta: ar ? 'بواسطة خالد العمري' : 'by Khalid Al-Omari' }] : [])]} /></Section>
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Button variant="secondary" size="sm" icon="pencil-line">{d.changeRsvp}</Button><Button variant="secondary" size="sm" icon="link">{d.copyLink}</Button></div>
  </Drawer>;
}
Object.assign(window, { Guests });
