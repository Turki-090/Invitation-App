const { Card, Tabs, Button, Field, Select, Radio, Tag, Dialog, Banner, StatCard, StatusPill, Input, Toast, Icon } = DS;
const WA_MSG = {
  ar: { hello: n => `مرحبًا ${n}،`, body: 'بمشيئة الله يسرّنا دعوتكم لحضور حفل زواج محمد ونورة.', when: 'الخميس ١٤ مايو ٢٠٢٦ · ٨:٣٠ م', where: 'قاعة الماسة — الرياض', scope: { single: 'هذه الدعوة خاصة بك.', family: 'هذه الدعوة تشمل ٤ أشخاص من العائلة.', companions: 'هذه الدعوة لك ولمرافقَين اثنين على الأكثر.' }, btns: { single: ['سأحضر', 'أعتذر'], family: ['سيحضر الجميع', 'اختيار الحاضرين', 'يعتذر الجميع'], companions: ['أنا فقط', 'أنا + ١', 'أنا + ٢', 'أعتذر'] }, view: 'عرض الدعوة' },
  en: { hello: n => `Hello ${n},`, body: 'We are pleased to invite you to the wedding of Mohammed & Noura.', when: 'Thursday 14 May 2026 · 8:30 PM', where: 'Al Masa Hall — Riyadh', scope: { single: 'This invitation is for you.', family: 'This invitation includes 4 members of your family.', companions: 'This invitation is for you and up to two companions.' }, btns: { single: ['I will attend', 'Decline'], family: ['Everyone attending', 'Select attendees', 'Everyone declines'], companions: ['Me only', 'Me + 1', 'Me + 2', 'Decline'] }, view: 'View invitation' },
};
function WaPreview({ type, lang, name }) {
  const m = WA_MSG[lang];
  return <div dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{ background: 'var(--wa-bg)', borderRadius: 'var(--radius-lg)', padding: 14, display: 'flex', flexDirection: 'column', gap: 6 }}>
    <div style={{ background: 'var(--wa-bubble-in)', borderRadius: 10, padding: '10px 12px', fontSize: 14, lineHeight: 1.6, boxShadow: '0 1px 1px rgba(0,0,0,.08)', color: '#111B21' }}>
      <div>{m.hello(name)}</div><div style={{ marginTop: 6 }}>{m.body}</div><div style={{ marginTop: 8, fontWeight: 600 }}>{m.when}<br />{m.where}</div><div style={{ marginTop: 8 }}>{m.scope[type]}</div>
      <div style={{ textAlign: 'end', fontSize: 11, color: '#667781', marginTop: 4 }}>7:32 PM</div>
    </div>
    {[m.view, ...m.btns[type]].map((b, i) => <div key={b} style={{ background: 'var(--wa-bubble-in)', borderRadius: 10, padding: '10px 12px', textAlign: 'center', fontSize: 14, fontWeight: 500, color: 'var(--wa-link)', boxShadow: '0 1px 1px rgba(0,0,0,.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>{i === 0 ? <Icon name="external-link" size={15} /> : <Icon name="reply" size={15} />}{b}</div>)}
  </div>;
}
function Sending({ t, lang }) {
  const ar = lang === 'ar'; const [type, setType] = React.useState('companions'); const [aud, setAud] = React.useState('unsent'); const [confirm, setConfirm] = React.useState(false); const [progress, setProgress] = React.useState(null);
  const names = { single: ar ? 'سارة' : 'Sarah', family: ar ? 'عائلة الدوسري' : 'Al-Dosari family', companions: ar ? 'محمد' : 'Mohammed' };
  const send = () => { setConfirm(false); setProgress({ queued: 29, sent: 0, delivered: 0, failed: 0 }); let i = 0; const iv = setInterval(() => { i++; setProgress({ queued: Math.max(0, 29 - i * 4), sent: Math.min(29, i * 4), delivered: Math.min(27, Math.max(0, i * 4 - 3)), failed: i > 5 ? 2 : 0 }); if (i >= 8) clearInterval(iv); }, 500); };
  return <>
    <PageHeader title={t.nav.sending} meta={ar ? '٢٩ مجموعة دعوات جاهزة للإرسال · ٤٢٣ أُرسلت سابقًا' : '29 invitation groups ready to send · 423 already sent'}>
      <Button variant="secondary" icon="smartphone">{ar ? 'إرسال رسالة تجريبية' : 'Send test message'}</Button>
      <Button icon="send" onClick={() => setConfirm(true)}>{ar ? 'إرسال ٢٩ دعوة' : 'Send 29 invitations'}</Button>
    </PageHeader>
    {progress ? <Card title={ar ? 'تقدّم الإرسال' : 'Sending progress'} subtitle={ar ? 'لا تُرسل كل الرسائل فورًا — قد يستغرق التوصيل دقائق.' : 'Messages don’t all send instantly — delivery can take minutes.'} style={{ marginBottom: 14 }}>
      <div className="grid4">
        <StatCard label={ar ? 'في الانتظار' : 'Queued'} value={progress.queued} lang={lang} tone="pending" />
        <StatCard label={t.sent} value={progress.sent} lang={lang} tone="notsent" />
        <StatCard label={t.delivered} value={progress.delivered} lang={lang} tone="partial" />
        <StatCard label={ar ? 'فشل' : 'Failed'} value={progress.failed} lang={lang} tone="failed" />
      </div>
      {progress.failed > 0 ? <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[[ar ? 'نواف الحربي' : 'Nawaf Al-Harbi', '+966544000999', ar ? 'الرقم غير متاح على واتساب' : 'Number not available on WhatsApp'], [ar ? 'هند السبيعي' : 'Hind Al-Subaie', '+96651122334', ar ? 'رقم غير صالح' : 'Invalid phone number']].map(([n, p, r]) => <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)' }}><StatusPill kind="delivery" status="failed" lang={lang} size="sm" /><span style={{ fontWeight: 500 }}>{n}</span><DS.Phone value={p} /><span style={{ flex: 1, fontSize: 13, color: 'var(--text-secondary)' }}>{r}</span><Button size="sm" variant="secondary" icon="pencil">{ar ? 'تعديل الرقم' : 'Edit number'}</Button><Button size="sm" variant="secondary" icon="refresh-cw">{ar ? 'إعادة المحاولة' : 'Retry'}</Button><Button size="sm" variant="ghost">{ar ? 'إزالة' : 'Remove'}</Button></div>)}
      </div> : null}
    </Card> : null}
    <div className="two">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Card title={ar ? 'قالب الرسالة' : 'Message template'}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <Field label={ar ? 'القالب' : 'Template'}><Select value="formal" options={[{ value: 'formal', label: ar ? 'الدعوة الرسمية' : 'Formal invitation' }, { value: 'warm', label: ar ? 'الدعوة الودّية' : 'Warm invitation' }]} /></Field>
            <Field label={ar ? 'اللغة' : 'Language'}><Select value={lang} options={[{ value: 'ar', label: 'العربية' }, { value: 'en', label: 'English' }]} /></Field>
          </div>
          <Field label={ar ? 'رسالة إضافية (اختياري)' : 'Extra message (optional)'} hint={ar ? 'المتغيرات تُستبدل تلقائيًا لكل ضيف.' : 'Variables fill in automatically per guest.'}>
            <textarea rows={4} defaultValue={ar ? 'يشرفنا حضوركم ومشاركتنا الفرحة.' : 'We would be honoured to have you share our joy.'} style={{ width: '100%', padding: 12, border: '1px solid var(--border-strong)', borderRadius: 'var(--radius-control)', background: 'var(--surface-card)', resize: 'vertical', fontSize: 14, lineHeight: 1.6 }} />
          </Field>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 10 }}>{(ar ? ['اسم الضيف', 'اسم المناسبة', 'التاريخ', 'الوقت', 'المكان', 'عدد المرافقين'] : ['Guest name', 'Event name', 'Date', 'Time', 'Venue', 'Allowed companions']).map(v => <Tag key={v} tone="outline" size="sm">{'{' + v + '}'}</Tag>)}</div>
        </Card>
        <Card title={ar ? 'الجمهور' : 'Audience'} subtitle={ar ? 'من سيستلم هذه الدعوة؟' : 'Who receives this send?'}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Radio name="aud" value="unsent" checked={aud === 'unsent'} onChange={setAud} label={ar ? 'كل الدعوات غير المرسلة' : 'All unsent invitations'} description={ar ? '٢٩ مجموعة دعوات' : '29 invitation groups'} />
            <Radio name="aud" value="selected" checked={aud === 'selected'} onChange={setAud} label={ar ? 'المجموعات المحددة فقط' : 'Selected groups only'} description={ar ? 'لم تحدد أي مجموعة بعد' : 'No groups selected yet'} />
            <Radio name="aud" value="cat" checked={aud === 'cat'} onChange={setAud} label={ar ? 'تصنيف معيّن' : 'A specific category'} description={ar ? 'أهل العروس · أهل العريس · الأصدقاء…' : 'Bride’s family · Groom’s family · Friends…'} />
          </div>
        </Card>
        <Banner kind="success" icon="message-circle" title={ar ? 'واتساب متصل وجاهز للإرسال' : 'WhatsApp connected and ready to send'} description={ar ? 'القالب معتمد · ١٥٠ رصيدًا متبقيًا' : 'Template approved · 150 credits remaining'} actionLabel={ar ? 'الإعدادات' : 'Settings'} />
      </div>
      <Card title={ar ? 'معاينة واتساب' : 'WhatsApp preview'} subtitle={ar ? 'كل نوع دعوة يحصل على أزرار مختلفة' : 'Each invitation type gets different buttons'}>
        <Tabs variant="pill" value={type} onChange={setType} items={[{ id: 'single', label: t.types.single }, { id: 'family', label: t.types.family }, { id: 'companions', label: t.types.companions }]} style={{ marginBottom: 12 }} />
        <WaPreview type={type} lang={lang} name={names[type]} />
      </Card>
    </div>
    {confirm ? <Dialog title={ar ? 'إرسال ٢٩ دعوة الآن؟' : 'Send 29 invitations now?'} description={ar ? 'القالب: الدعوة الرسمية (عربي) · المستلمون: كل الدعوات غير المرسلة · سيُستخدم ٢٩ رصيدًا من ١٥٠. لا يمكن التراجع عن الرسائل بعد إرسالها.' : 'Template: Formal (Arabic) · Recipients: all unsent · 29 of 150 credits will be used. Messages cannot be recalled once sent.'} onClose={() => setConfirm(false)} actions={<><Button variant="secondary" onClick={() => setConfirm(false)}>{t.add.cancel}</Button><Button icon="send" onClick={send}>{ar ? 'إرسال الآن' : 'Send now'}</Button></>} /> : null}
  </>;
}
Object.assign(window, { Sending, WaPreview, WA_MSG });
