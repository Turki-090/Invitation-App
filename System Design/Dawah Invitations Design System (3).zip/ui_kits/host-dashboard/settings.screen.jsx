const { Card, Button, Field, Input, Select, Switch, Avatar, Tag, StatusPill, IconButton, Dialog, StatCard, EmptyState, ProgressBar, Checkbox, Icon } = DS;
function Settings({ t, lang }) {
  const ar = lang === 'ar'; const [del, setDel] = React.useState(false); const [typed, setTyped] = React.useState('');
  const S = ({ title, desc, children }) => <Card title={title} subtitle={desc}><div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>{children}</div></Card>;
  return <>
    <PageHeader title={t.nav.settings} meta={t.event}><Button variant="secondary">{ar ? 'إلغاء' : 'Discard'}</Button><Button>{ar ? 'حفظ التغييرات' : 'Save changes'}</Button></PageHeader>
    <div className="grid2" style={{ alignItems: 'start' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <S title={ar ? 'معلومات المناسبة' : 'Event information'}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label={ar ? 'اسم المناسبة' : 'Event name'}><Input defaultValue={t.event} /></Field>
            <Field label={ar ? 'نوع المناسبة' : 'Event type'}><Select value="wedding" options={[{ value: 'wedding', label: ar ? 'زواج' : 'Wedding' }, { value: 'eng', label: ar ? 'خطوبة' : 'Engagement' }, { value: 'grad', label: ar ? 'تخرج' : 'Graduation' }, { value: 'other', label: ar ? 'أخرى' : 'Other' }]} /></Field>
            <Field label={ar ? 'التاريخ' : 'Date'}><Input dir="ltr" mono defaultValue="2026-05-14" /></Field>
            <Field label={ar ? 'وقت البداية' : 'Start time'}><Input dir="ltr" mono defaultValue="20:30" /></Field>
            <Field label={ar ? 'القاعة' : 'Venue'}><Input defaultValue={ar ? 'قاعة الماسة' : 'Al Masa Hall'} /></Field>
            <Field label={ar ? 'المدينة' : 'City'}><Input defaultValue={ar ? 'الرياض' : 'Riyadh'} /></Field>
          </div>
          <Field label={ar ? 'رابط الخريطة' : 'Map link'}><Input dir="ltr" mono icon="map-pin" defaultValue="https://maps.app.goo.gl/…" /></Field>
        </S>
        <S title={ar ? 'إعدادات الردود' : 'RSVP settings'}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><Field label={ar ? 'موعد إغلاق الردود' : 'RSVP deadline'}><Input dir="ltr" mono defaultValue="2026-05-10" /></Field><Field label={ar ? 'اللغات' : 'Languages'}><Select value="both" options={[{ value: 'ar', label: 'العربية' }, { value: 'en', label: 'English' }, { value: 'both', label: ar ? 'العربية + English' : 'Arabic + English' }]} /></Field></div>
          <Switch checked label={ar ? 'السماح للضيوف بتغيير الرد' : 'Allow guests to change their response'} description={ar ? 'حتى موعد إغلاق الردود' : 'Until the RSVP deadline'} />
          <Switch checked label={ar ? 'قفل التغييرات قبل المناسبة' : 'Lock changes before the event'} description={ar ? '٢٤ ساعة قبل البداية' : '24 hours before start'} />
          <Switch checked label={ar ? 'التذكيرات التلقائية' : 'Automatic reminders'} description={ar ? 'تُدار من صفحة التذكيرات' : 'Managed on the Reminders page'} />
          <Switch label={ar ? 'بطاقة دخول QR' : 'QR entry pass'} description={ar ? 'يستلمها من قبل الدعوة عبر واتساب' : 'Sent on WhatsApp to accepted guests'} />
        </S>
        <Card style={{ borderColor: 'var(--danger-bg)' }} title={ar ? 'منطقة الخطر' : 'Danger zone'} subtitle={ar ? 'إجراءات لا يمكن التراجع عنها' : 'Actions that cannot be undone'}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Button variant="secondary" icon="archive">{ar ? 'أرشفة المناسبة' : 'Archive event'}</Button><Button variant="danger-soft" icon="trash-2" onClick={() => setDel(true)}>{ar ? 'حذف المناسبة' : 'Delete event'}</Button></div>
        </Card>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Card tone="accent" title={ar ? 'اتصال واتساب' : 'WhatsApp connection'} subtitle={ar ? 'متصل · القالب معتمد · جاهز للإرسال' : 'Connected · template approved · ready to send'} actions={<StatusPill kind="delivery" status="responded" label={ar ? 'جاهز' : 'Ready'} />}>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{ar ? 'رقم المرسل: ' : 'Sender number: '}<span className="phone">+966 11 200 0000</span><br />{ar ? 'الحالات الممكنة: غير متصل · يتطلب الإعداد · التحقق قيد الانتظار · القالب قيد الاعتماد · جاهز · غير متاح مؤقتًا' : 'States: not connected · setup required · verification pending · template pending · ready · temporarily unavailable'}</div>
        </Card>
        <Card title={ar ? 'حالة المناسبة' : 'Event status'}><div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>{['rsvp-open', 'rsvp-closed', 'completed', 'archived'].map(s => <StatusPill key={s} kind="event" status={s} lang={lang} variant={s === 'rsvp-open' ? 'soft' : 'plain'} />)}</div></Card>
      </div>
    </div>
    {del ? <Dialog danger title={ar ? 'حذف المناسبة نهائيًا؟' : 'Permanently delete this event?'} description={ar ? 'سيُحذف ٤٥٠ مجموعة دعوات و٦٢٠ ضيفًا وكل الردود والرسائل. اكتب اسم المناسبة للتأكيد.' : 'This removes 450 invitation groups, 620 guests and every RSVP and message. Type the event name to confirm.'} onClose={() => setDel(false)} actions={<><Button variant="secondary" onClick={() => setDel(false)}>{t.add.cancel}</Button><Button variant="danger" disabled={typed !== t.event} onClick={() => setDel(false)}>{ar ? 'حذف المناسبة' : 'Delete event'}</Button></>}><Field label={t.event}><Input value={typed} onChange={e => setTyped(e.target.value)} placeholder={t.event} /></Field></Dialog> : null}
  </>;
}
function Team({ t, lang }) {
  const ar = lang === 'ar'; const [invite, setInvite] = React.useState(false);
  const perms = ar ? ['إدارة قائمة الضيوف', 'إرسال الدعوات والتذكيرات', 'عرض أرقام الجوال كاملة', 'تصدير بيانات الضيوف', 'تعديل الردود يدويًا', 'تسجيل دخول الضيوف'] : ['Manage guest list', 'Send invitations & reminders', 'View full phone numbers', 'Export guest data', 'Manage RSVP manually', 'Check guests in'];
  const members = [[ar ? 'خالد العمري' : 'Khalid Al-Omari', ar ? 'المالك' : 'Owner', 'owner', [1, 1, 1, 1, 1, 1]], [ar ? 'نورة الشمري' : 'Noura Al-Shammari', ar ? 'مضيف مشارك' : 'Co-host', 'active', [1, 1, 1, 0, 1, 0]], [ar ? 'فهد الحارثي' : 'Fahad Al-Harthi', ar ? 'موظف تسجيل دخول' : 'Check-in staff', 'active', [0, 0, 0, 0, 0, 1]], [ar ? 'سلطان القحطاني' : 'Sultan Al-Qahtani', ar ? 'مضيف مشارك' : 'Co-host', 'pending', [1, 1, 0, 0, 0, 0]]];
  return <>
    <PageHeader title={t.nav.team} meta={ar ? 'المالك يتحكم بالصلاحيات · الفوترة والحذف ونقل الملكية للمالك فقط' : 'Owner controls permissions · billing, deletion and ownership transfer are owner-only'}><Button icon="user-plus" onClick={() => setInvite(true)}>{ar ? 'دعوة مضيف مشارك' : 'Invite co-host'}</Button></PageHeader>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {members.map(([n, r, st, p]) => <Card key={n} padding="16px">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <Avatar name={n} tone={st === 'owner' ? 'dark' : 'soft'} /><div style={{ minWidth: 180 }}><div style={{ fontWeight: 600 }}>{n}</div><div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{r}</div></div>
          {st === 'pending' ? <><StatusPill kind="delivery" status="queued" label={ar ? 'دعوة معلّقة' : 'Invitation pending'} lang={lang} size="sm" /><Button size="sm" variant="secondary" icon="refresh-cw">{ar ? 'إعادة الإرسال' : 'Resend'}</Button><Button size="sm" variant="ghost">{ar ? 'إلغاء الدعوة' : 'Revoke'}</Button></> : null}
          <span style={{ flex: 1 }} />
          {st !== 'owner' ? <IconButton name="ellipsis" label={t.more} size="sm" /> : <Tag tone="accent" size="sm">{ar ? 'صلاحيات كاملة' : 'Full access'}</Tag>}
        </div>
        {st !== 'owner' ? <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '10px 20px', marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--border-default)' }}>{perms.map((pl, i) => <Switch key={pl} checked={!!p[i]} label={pl} disabled={st === 'pending'} />)}</div> : null}
      </Card>)}
    </div>
    {invite ? <Dialog title={ar ? 'دعوة مضيف مشارك' : 'Invite co-host'} description={ar ? 'سيستلم رابط الانضمام عبر واتساب أو البريد.' : 'They’ll receive a join link on WhatsApp or email.'} onClose={() => setInvite(false)} actions={<><Button variant="secondary" onClick={() => setInvite(false)}>{t.add.cancel}</Button><Button icon="send" onClick={() => setInvite(false)}>{ar ? 'إرسال الدعوة' : 'Send invite'}</Button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}><Field label={ar ? 'رقم الجوال أو البريد' : 'Mobile or email'}><DS.PhoneInput /></Field><Field label={ar ? 'الدور' : 'Role'}><Select value="cohost" options={[{ value: 'cohost', label: ar ? 'مضيف مشارك' : 'Co-host' }, { value: 'checkin', label: ar ? 'موظف تسجيل دخول' : 'Check-in staff' }]} /></Field><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>{perms.map((pl, i) => <Checkbox key={pl} checked={i < 2} label={pl} />)}</div></div>
    </Dialog> : null}
  </>;
}
function Checkin({ t, lang }) {
  const ar = lang === 'ar'; const [q, setQ] = React.useState(''); const [res, setRes] = React.useState(null); const [n, setN] = React.useState(3);
  return <>
    <PageHeader title={t.nav.checkin} meta={ar ? 'وضع تسجيل الدخول — يعمل على الجوال والتابلت · يدعم العمل دون اتصال' : 'Check-in mode — phone & tablet friendly · works offline'}><Button variant="accent" size="lg" icon="scan-line" onClick={() => setRes('scan')}>{ar ? 'مسح رمز QR' : 'Scan QR'}</Button></PageHeader>
    <div className="grid4" style={{ marginBottom: 14 }}>
      <StatCard label={t.expected} value={497} context={t.peopleUnit} lang={lang} size="lg" /><StatCard label={t.checkedin} value={212} context={t.peopleUnit} tone="checkedin" lang={lang} size="lg" /><StatCard label={t.remaining} value={285} context={t.peopleUnit} tone="notsent" lang={lang} size="lg" /><StatCard label={t.checkinPct} value={ar ? '٤٣٪' : '43%'} lang={lang} size="lg" />
    </div>
    <div className="two">
      <Card title={ar ? 'بحث عن ضيف' : 'Search guest'} subtitle={ar ? 'للضيوف الذين فقدوا رمز QR — بالاسم أو العائلة أو الجوال' : 'For guests without their QR — name, family or mobile'}>
        <Input icon="search" size="lg" placeholder={t.search} value={q} onChange={e => { setQ(e.target.value); setRes(e.target.value ? 'found' : null); }} />
        {res === 'found' || res === 'scan' ? <div style={{ marginTop: 14, padding: 18, border: '1px solid var(--border-default)', borderRadius: 'var(--radius-card)', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><Avatar name={ar ? 'محمد العتيبي' : 'Mohammed Al-Otaibi'} size="lg" /><div style={{ flex: 1 }}><div style={{ fontSize: 20, fontWeight: 600 }}>{ar ? 'محمد العتيبي' : 'Mohammed Al-Otaibi'}</div><div style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{ar ? 'العدد المؤكد: ٣ أشخاص (١ + ٢ مرافقان)' : 'Confirmed party: 3 people (1 + 2 companions)'}</div></div><StatusPill kind="checkin" status="not-arrived" lang={lang} /></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}><span style={{ fontSize: 14, fontWeight: 500 }}>{ar ? 'كم شخصًا وصل؟' : 'How many arrived?'}</span><DS.Stepper value={n} max={3} onChange={setN} format={v => fmt(v, lang)} size="guest" /><Button size="lg" variant="accent" icon="badge-check" style={{ flex: 1 }} onClick={() => setRes('done')}>{ar ? `تسجيل دخول ${fmt(n, lang)} ${n === 3 ? '(الجميع)' : ''}` : `Check in ${n}${n === 3 ? ' (all)' : ''}`}</Button></div>
        </div> : res === 'done' ? <div style={{ marginTop: 14, padding: 24, background: 'var(--checkedin-bg)', borderRadius: 'var(--radius-card)', display: 'flex', alignItems: 'center', gap: 14, color: 'var(--checkedin-fg)' }}><Icon name="badge-check" size={36} color="var(--checkedin)" /><div><div style={{ fontSize: 20, fontWeight: 600 }}>{ar ? 'تم تسجيل دخول محمد العتيبي' : 'Mohammed Al-Otaibi checked in'}</div><div style={{ fontSize: 14 }}>{ar ? `${fmt(n, lang)} من ٣ أشخاص · ٨:٤١ م` : `${n} of 3 people · 8:41 PM`}</div></div><Button variant="secondary" style={{ marginInlineStart: 'auto' }} onClick={() => setRes('dup')}>{ar ? 'مسح التالي' : 'Scan next'}</Button></div>
        : res === 'dup' ? <div style={{ marginTop: 14, padding: 24, background: 'var(--pending-bg)', borderRadius: 'var(--radius-card)', display: 'flex', alignItems: 'center', gap: 14, color: 'var(--pending-fg)' }}><Icon name="triangle-alert" size={36} color="var(--pending)" /><div><div style={{ fontSize: 20, fontWeight: 600 }}>{ar ? 'هذه الدعوة سُجّل دخولها مسبقًا عند ٨:٤١ م' : 'This invitation was already checked in at 8:41 PM'}</div><div style={{ fontSize: 14 }}>{ar ? 'محمد العتيبي · ٣ من ٣ أشخاص' : 'Mohammed Al-Otaibi · 3 of 3 people'}</div></div><Button variant="secondary" style={{ marginInlineStart: 'auto' }} onClick={() => setRes(null)}>{ar ? 'حسنًا' : 'OK'}</Button></div>
        : <EmptyState compact icon="qr-code" title={ar ? 'امسح رمز QR أو ابحث عن ضيف' : 'Scan a QR code or search for a guest'} description={ar ? 'رمز QR يمثّل مجموعة الدعوة كاملة، وليس شخصًا واحدًا.' : 'A QR represents the whole invitation group, not one person.'} />}
      </Card>
      <Card title={t.arrivals}><DS.Timeline dense items={(ar ? [['عائلة العنزي — ٣ أشخاص', '٨:٤١ م'], ['سارة القحطاني', '٨:٣٩ م'], ['عائلة الدوسري — ٢ من ٣', '٨:٣٠ م']] : [['Al-Anazi family — 3 people', '8:41 PM'], ['Sarah Al-Qahtani', '8:39 PM'], ['Al-Dosari family — 2 of 3', '8:30 PM']]).map(([label, time], i) => ({ label, time, icon: i === 2 ? 'users' : 'badge-check', tone: i === 2 ? 'partial' : 'checkedin' }))} /></Card>
    </div>
  </>;
}
function Reports({ t, lang }) {
  const ar = lang === 'ar';
  const exports = ar ? ['قائمة الضيوف الكاملة', 'الحاضرون المؤكدون', 'الضيوف المعلّقون', 'قائمة تسجيل الدخول', 'تقرير الحضور النهائي'] : ['Full guest list', 'Confirmed attendees', 'Pending guests', 'Check-in list', 'Final attendance report'];
  return <>
    <PageHeader title={t.nav.reports} meta={ar ? 'التقارير تفرّق دائمًا بين مجموعات الدعوات والأشخاص' : 'Reports always separate invitation groups from people'}><Button variant="secondary" icon="download">{ar ? 'تصدير الكل (Excel)' : 'Export all (Excel)'}</Button></PageHeader>
    <div className="grid3" style={{ marginBottom: 14 }}>
      <Card title={ar ? 'ملخص الردود' : 'RSVP summary'} subtitle={`${fmt(450, lang)} ${t.groupsUnit}`}><ProgressBar lang={lang} segments={[{ label: t.accepted, value: 280, tone: 'accepted' }, { label: t.partial, value: 31, tone: 'partial' }, { label: t.declined, value: 54, tone: 'declined' }, { label: t.pending, value: 85, tone: 'pending' }]} /></Card>
      <Card title={ar ? 'الحضور' : 'Attendance'} subtitle={`${fmt(497, lang)} ${t.peopleUnit}`}><ProgressBar lang={lang} segments={[{ label: t.checkedin, value: 212, tone: 'checkedin' }, { label: ar ? 'لم يصلوا' : 'No-show so far', value: 285, tone: 'notsent' }]} /></Card>
      <Card title={ar ? 'نوع الدعوة' : 'Invitation type'} subtitle={`${fmt(450, lang)} ${t.groupsUnit}`}><ProgressBar lang={lang} segments={[{ label: t.types.single, value: 210, tone: 'notsent' }, { label: t.types.family, value: 150, tone: 'partial' }, { label: t.types.companions, value: 90, tone: 'checkedin' }]} /></Card>
    </div>
    <Card title={ar ? 'التصدير' : 'Exports'}><div style={{ display: 'flex', flexDirection: 'column' }}>{exports.map((e, i) => <div key={e} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderTop: i ? '1px solid var(--border-default)' : 'none' }}><Icon name="file-spreadsheet" size={18} color="var(--text-muted)" /><span style={{ flex: 1, fontWeight: 500 }}>{e}</span><Button size="sm" variant="secondary" icon="download">Excel</Button><Button size="sm" variant="ghost">CSV</Button></div>)}</div></Card>
  </>;
}
Object.assign(window, { Settings, Team, Checkin, Reports });
