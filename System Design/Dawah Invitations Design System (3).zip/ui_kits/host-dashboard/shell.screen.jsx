const { Icon, IconButton, Avatar, Button, Input, StatusPill } = DS;
const NAV = [['overview', 'layout-dashboard'], ['guests', 'users'], ['sending', 'send'], ['reminders', 'bell-ring'], ['checkin', 'qr-code'], ['team', 'user-plus'], ['reports', 'chart-column'], ['settings', 'settings']];
function Sidebar({ t, page, setPage, lang }) {
  return (
    <aside className="side">
      <div style={{ height: 'var(--topbar-h)', display: 'flex', alignItems: 'center', gap: 10, padding: '0 20px', borderBottom: '1px solid var(--border-default)' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 26, lineHeight: 1, color: 'var(--ink)' }}>دعوة</span>
        <span className="lbl" style={{ fontSize: 11, letterSpacing: '.12em', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Dawah</span>
      </div>
      <button className="ev" type="button" title={t.switchEvent} style={{ margin: 12, padding: '10px 12px', textAlign: 'start', background: 'var(--surface-sunken)', border: '1px solid transparent', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
        <span style={{ flex: 1, minWidth: 0 }}><span style={{ display: 'block', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.event}</span><StatusPill kind="event" status="rsvp-open" lang={lang} size="sm" variant="plain" style={{ padding: 0, height: 18 }} /></span>
        <Icon name="chevrons-up-down" size={16} color="var(--text-muted)" />
      </button>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '4px 12px', flex: 1 }}>
        {NAV.map(([id, ic]) => { const on = page === id; return (
          <button key={id} type="button" onClick={() => setPage(id)} aria-current={on ? 'page' : undefined} style={{ display: 'flex', alignItems: 'center', gap: 12, height: 40, padding: '0 12px', border: 0, borderRadius: 'var(--radius-md)', background: on ? 'var(--ink)' : 'transparent', color: on ? 'var(--text-on-dark)' : 'var(--text-secondary)', fontSize: 14, fontWeight: on ? 600 : 500, cursor: 'pointer', textAlign: 'start', transition: 'var(--transition-control)' }}>
            <Icon name={ic} size={18} /><span className="lbl" style={{ flex: 1 }}>{t.nav[id]}</span>{id === 'sending' && <span className="lbl num" style={{ fontSize: 11, fontWeight: 600, padding: '1px 7px', borderRadius: 999, background: on ? 'rgba(255,255,255,.18)' : 'var(--pending-bg)', color: on ? '#fff' : 'var(--pending-fg)' }}>{fmt(29, lang)}</span>}
          </button>); })}
      </nav>
      <div className="ev" style={{ margin: 12, padding: 12, borderRadius: 'var(--radius-md)', background: 'var(--accent-soft)', display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--accent-hover)', fontWeight: 600 }}><span>{t.credits}</span><Icon name="credit-card" size={14} /></div>
        <div style={{ height: 6, borderRadius: 999, background: 'rgba(154,118,66,.2)' }}><span style={{ display: 'block', width: '25%', height: '100%', borderRadius: 999, background: 'var(--accent)' }} /></div>
        <div className="num" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{t.creditsLeft}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 20px', borderTop: '1px solid var(--border-default)' }}>
        <Avatar name={t.user} size="sm" tone="dark" /><span className="lbl" style={{ flex: 1, minWidth: 0 }}><span style={{ display: 'block', fontSize: 13, fontWeight: 600 }}>{t.user}</span><span style={{ display: 'block', fontSize: 12, color: 'var(--text-muted)' }}>{t.role}</span></span><IconButton name="log-out" label="Log out" size="sm" flipRtl />
      </div>
    </aside>
  );
}
function Topbar({ t, title, lang, setLang }) {
  return (
    <header style={{ height: 'var(--topbar-h)', flex: 'none', display: 'flex', alignItems: 'center', gap: 12, padding: '0 var(--gutter)', background: 'var(--surface-card)', borderBottom: '1px solid var(--border-default)' }}>
      <h1 style={{ margin: 0, fontSize: 'var(--text-lg)', fontWeight: 600, flex: 1, whiteSpace: 'nowrap' }}>{title}</h1>
      <div className="hide-sm"><Input icon="search" placeholder={t.search} size="sm" style={{ width: 300 }} /></div>
      <Button variant="ghost" size="sm" icon="languages" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{t.lang}</Button>
      <IconButton name="circle-help" label={t.help} size="sm" /><IconButton name="bell" label={t.notif} size="sm" badge />
    </header>
  );
}
function BottomNav({ t, page, setPage }) {
  return <nav className="bottomnav" style={{ position: 'absolute', bottom: 0, insetInline: 0, height: 64, background: 'var(--surface-card)', borderTop: '1px solid var(--border-default)', justifyContent: 'space-around', alignItems: 'center', zIndex: 5 }}>
    {NAV.slice(0, 5).map(([id, ic]) => <button key={id} type="button" onClick={() => setPage(id)} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, border: 0, background: 'transparent', color: page === id ? 'var(--ink)' : 'var(--text-muted)', fontSize: 11, fontWeight: 600, minWidth: 56, minHeight: 44, cursor: 'pointer' }}><Icon name={ic} size={20} />{t.nav[id]}</button>)}
  </nav>;
}
function PageHeader({ title, meta, children }) {
  return <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 20, flexWrap: 'wrap' }}>
    <div><h2 style={{ margin: 0, fontSize: 'var(--text-2xl)', fontWeight: 600, lineHeight: 1.25 }}>{title}</h2>{meta ? <div style={{ marginTop: 4, fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{meta}</div> : null}</div>
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>{children}</div>
  </div>;
}
function Drawer({ title, onClose, children, footer, width = 'var(--drawer-w)' }) {
  return <>
    <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'var(--scrim)', zIndex: 20 }} />
    <aside role="dialog" aria-modal style={{ position: 'absolute', top: 0, bottom: 0, insetInlineEnd: 0, width, maxWidth: '100%', background: 'var(--surface-card)', boxShadow: 'var(--shadow-overlay)', zIndex: 21, display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 20px', borderBottom: '1px solid var(--border-default)' }}><h2 style={{ margin: 0, fontSize: 'var(--text-lg)', fontWeight: 600, flex: 1 }}>{title}</h2><IconButton name="x" label="close" size="sm" onClick={onClose} /></div>
      <div style={{ flex: 1, overflow: 'auto', padding: 20, display: 'flex', flexDirection: 'column', gap: 18 }}>{children}</div>
      {footer ? <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', padding: '14px 20px', borderTop: '1px solid var(--border-default)', flexWrap: 'wrap' }}>{footer}</div> : null}
    </aside>
  </>;
}
function Section({ title, children, style }) {
  return <section style={{ display: 'flex', flexDirection: 'column', gap: 10, ...style }}><h3 style={{ margin: 0, fontSize: 'var(--text-xs)', fontWeight: 600, color: 'var(--text-muted)', letterSpacing: '.04em' }}>{title}</h3>{children}</section>;
}
Object.assign(window, { Sidebar, Topbar, BottomNav, PageHeader, Drawer, Section });
