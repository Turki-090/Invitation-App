const { Card, Button, StatCard, Switch, Timeline, Dialog, Banner, Select, Field } = DS;
function Reminders({ t, lang }) {
  const ar = lang === 'ar'; const [seg, setSeg] = React.useState('none'); const [auto, setAuto] = React.useState(true); const [confirm, setConfirm] = React.useState(false);
  const segs = [['none', ar ? 'لم يردّوا' : 'No response', 89, 'pending'], ['unread', ar ? 'أُرسلت ولم تُقرأ' : 'Sent but unread', 22, 'notsent'], ['read', ar ? 'قُرئت دون رد' : 'Read, no response', 67, 'partial'], ['deadline', ar ? 'قرب انتهاء موعد الرد' : 'Deadline approaching', 89, 'declined']];
  const cur = segs.find(s => s[0] === seg);
  return <>
    <PageHeader title={t.nav.reminders} meta={ar ? 'ينتهي موعد الردود الأحد ١٠ مايو · التذكيرات لا تُرسل لمن قبل أو اعتذر أو فشل رقمه' : 'RSVP closes Sun 10 May · Reminders skip accepted, declined and failed numbers'}>
      <Button icon="bell" onClick={() => setConfirm(true)}>{ar ? `إرسال تذكير إلى ${fmt(cur[2], lang)} مجموعة` : `Send reminder to ${cur[2]} groups`}</Button>
    </PageHeader>
    <div className="grid4" style={{ marginBottom: 14 }}>{segs.map(([id, l, v, tone]) => <StatCard key={id} label={l} value={v} context={t.groupsUnit} tone={tone} lang={lang} onClick={() => setSeg(id)} style={seg === id ? { borderColor: 'var(--ink)', boxShadow: '0 0 0 1px var(--ink)' } : undefined} />)}</div>
    <div className="grid2">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Banner kind="warning" title={ar ? 'أرسلت لـ ٤١ من هؤلاء الضيوف تذكيرًا أمس' : 'You sent 41 of these guests a reminder yesterday'} description={ar ? 'سيتم استثناؤهم تلقائيًا لتجنّب الإزعاج.' : 'They’ll be excluded automatically to avoid spamming.'} actionLabel={ar ? 'عرضهم' : 'Show them'} />
        <Card title={ar ? 'التذكيرات التلقائية' : 'Automatic reminders'} actions={<Switch checked={auto} onChange={setAuto} />}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, opacity: auto ? 1 : .5 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}><Field label={ar ? 'التذكير الأول' : 'First reminder'}><Select value="3d" options={[{ value: '3d', label: ar ? '٣ أيام بعد الدعوة' : '3 days after invitation' }, { value: '5d', label: ar ? '٥ أيام بعد الدعوة' : '5 days after invitation' }]} /></Field><Field label={ar ? 'التذكير النهائي' : 'Final reminder'}><Select value="2d" options={[{ value: '2d', label: ar ? 'يومان قبل إغلاق الردود' : '2 days before RSVP closes' }, { value: '1d', label: ar ? 'يوم قبل إغلاق الردود' : '1 day before RSVP closes' }]} /></Field></div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{ar ? 'لا يُرسل تذكير إلى: من قبلوا · من اعتذروا · الأرقام الفاشلة · الدعوات الملغاة' : 'Never reminded: accepted · declined · failed numbers · cancelled invitations'}</div>
          </div>
        </Card>
      </div>
      <Card title={ar ? 'سجل التذكيرات' : 'Reminder history'}>
        <Timeline items={(ar ? [['التذكير التلقائي الأول', 'أمس ٦:٠٠ م', 'أُرسل إلى ١٠٤ مجموعات · ردّ ٣١'], ['تذكير يدوي — أهل العريس', '٤ مايو', 'أُرسل إلى ٤١ مجموعة · بواسطة نورة الشمري'], ['التذكير النهائي', 'الجمعة ٨ مايو', 'مجدول']] : [['First automatic reminder', 'Yesterday 6:00 PM', 'Sent to 104 groups · 31 responded'], ['Manual reminder — Groom’s family', '4 May', 'Sent to 41 groups · by Noura Al-Shammari'], ['Final reminder', 'Fri 8 May', 'Scheduled']]).map(([label, time, meta], i) => ({ label, time, meta, tone: i === 2 ? 'pending' : 'checkedin', hollow: i === 2, icon: i === 2 ? undefined : 'bell' }))} />
      </Card>
    </div>
    {confirm ? <Dialog title={ar ? `إرسال تذكير إلى ${fmt(cur[2] - 41, lang)} مجموعة؟` : `Send reminder to ${cur[2] - 41} groups?`} description={ar ? 'استُثني ٤١ ضيفًا تلقّوا تذكيرًا أمس. الرسالة: "نودّ تذكيركم بدعوتنا…"' : '41 guests reminded yesterday are excluded. Message: “A gentle reminder of our invitation…”'} onClose={() => setConfirm(false)} actions={<><Button variant="secondary" onClick={() => setConfirm(false)}>{t.add.cancel}</Button><Button icon="bell" onClick={() => setConfirm(false)}>{ar ? 'إرسال التذكير' : 'Send reminder'}</Button></>} /> : null}
  </>;
}
Object.assign(window, { Reminders });
