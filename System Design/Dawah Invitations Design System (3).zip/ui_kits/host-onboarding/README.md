# UI kit — Host onboarding

Click-through of the first-run flow: **Sign in** (mobile number, OTP hint, email fallback) → **Verification code** (large LTR mono field; `1234` succeeds, anything else shows the invalid/expired error and enables resend) → **Events home** (event cards with status pill, groups / RSVP % / expected people, open · duplicate · archive; empty-state toggle) → **Create-event wizard** (event type choice cards → details → RSVP settings → WhatsApp connection with all six states + readiness checklist).

A floating pill bar (bottom-start) jumps between steps and toggles Arabic/English. Split-screen auth uses the ink panel with Amiri tagline — the only place display type appears on the host side.
