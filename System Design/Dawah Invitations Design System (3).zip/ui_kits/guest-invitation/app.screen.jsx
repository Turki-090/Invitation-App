const { Tabs, Switch, Button } = DS;
function App() {
  const [lang, setLang] = React.useState('ar'); const [phase, setPhase] = React.useState('open'); const [qr, setQr] = React.useState(true);
  const ar = lang === 'ar';
  return <div dir={ar ? 'rtl' : 'ltr'}>
    <div className="bar">
      <Tabs variant="pill" value={phase} onChange={setPhase} items={[{ id: 'open', label: ar ? 'الردود مفتوحة' : 'RSVP open' }, { id: 'closed', label: ar ? 'الردود مغلقة' : 'RSVP closed' }, { id: 'completed', label: ar ? 'بعد المناسبة' : 'Event completed' }]} />
      <Switch checked={qr} onChange={setQr} label={ar ? 'بطاقة QR' : 'QR pass'} />
      <Button variant="ghost" size="sm" icon="languages" onClick={() => setLang(ar ? 'en' : 'ar')}>{ar ? 'English' : 'العربية'}</Button>
    </div>
    <div className="phones">
      {['single', 'family', 'companions'].map(type => <div key={type} className="phone"><Invitation key={type + lang + phase} type={type} lang={lang} phase={phase} qrEnabled={qr} /></div>)}
    </div>
  </div>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
