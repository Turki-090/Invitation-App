# UI kit — Guest invitation

Phone-first (390px) visual invitation opened from the WhatsApp "View invitation" button. No navigation bar, no login. The only expressive, wedding-themed surface in the system: cream paper, Amiri display type, thin gold rules.

`index.html` shows the three invitation types side by side, each independently interactive:
- **Single** — "دعوة خاصة لك" → سأحضر / أعتذر
- **Named family** — 28px member checkboxes, live "٣ من ٤ سيحضرون", confirm / everyone declines
- **Person + companions** — Me only / Me + 1 / Me + 2 choice cards, then confirm / decline

Top bar switches RSVP open → closed (shows recorded response, or "contact the host" if none) → event completed ("Thank you for sharing our celebration", RSVP hidden); toggles the QR entry pass; switches Arabic/English.

Rules embodied: 60px stacked RSVP buttons (never side-by-side), 17px minimum text, icon + text on every state, no disabled buttons without explanation.

Files: `invitation.screen.jsx` (one screen, all states), `app.screen.jsx` (frame + controls).
